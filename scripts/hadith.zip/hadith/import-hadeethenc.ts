import { createHash } from "node:crypto";
import { mkdir, readFile, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { dirname, join } from "node:path";

type JsonObject = Record<string, unknown>;

type CliArgs = {
  limit: number;
  corpusVersion: string;
  import: boolean;
  validateOnly: boolean;
  output: string;
  cache: string;
  mapping: string;
  lifecycleAuthor: string | null;
  lifecycleJustification: string | null;
  lifecycleEvidence: string | null;
};

type SourceCategory = {
  sourceCategoryId: string;
  sourceCategoryLabel: string;
  language: string;
  parentSourceCategoryId: string | null;
  sourceHadeethsCount: number | null;
  retrievedAt: string;
};

type ThemeProposal = {
  stableKey: string;
  status: "exact" | "certain";
  sourceCategoryId: string;
  sourceCategoryLabel: string;
};

type HadeethEncRecord = {
  sourceHadithId: string;
  sourceUrl: string;
  title: string | null;
  hadeethAr: string;
  hadeeth: string | null;
  hadeethIntro: string | null;
  hadeethIntroAr: string | null;
  attribution: string | null;
  attributionAr: string | null;
  grade: string | null;
  gradeAr: string | null;
  explanation: string | null;
  explanationAr: string | null;
  hints: unknown[] | null;
  hintsAr: unknown[] | null;
  wordsMeaningsAr: unknown[] | null;
  sourceReference: string | null;
  categories: SourceCategory[];
  themes: ThemeProposal[];
  retrievedAt: string;
  documentHash: string;
};

type Payload = {
  source: {
    name: "HadeethEnc";
    organization: "HadeethEnc";
    officialUrl: string;
    termsUrl: string;
    language: "fr";
    corpusVersion: string;
    attribution: string;
    license: string | null;
  };
  records: HadeethEncRecord[];
};

const API = "https://hadeethenc.com/api/v1";
const TIMEOUT_MS = 30_000;
const MAX_RPC_BATCH = 50;
const MAX_RETRIES = 3;

function stableStringify(value: unknown): string {
  if (value === null || typeof value !== "object") {
    return JSON.stringify(value);
  }

  if (Array.isArray(value)) {
    return `[${value.map(stableStringify).join(",")}]`;
  }

  const object = value as JsonObject;
  return `{${Object.keys(object)
    .sort()
    .map(
      (key) =>
        `${JSON.stringify(key)}:${stableStringify(object[key])}`,
    )
    .join(",")}}`;
}

function sha256(value: unknown): string {
  return createHash("sha256")
    .update(stableStringify(value), "utf8")
    .digest("hex");
}

function cleanText(value: unknown): string | null {
  return typeof value === "string" && value.trim()
    ? value.trim()
    : null;
}

function asArray(value: unknown): unknown[] | null {
  return Array.isArray(value) ? value : null;
}

function asObject(value: unknown): JsonObject {
  return value !== null && typeof value === "object"
    ? (value as JsonObject)
    : {};
}

function sleep(milliseconds: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, milliseconds));
}

function parseArgs(argv: string[]): CliArgs {
  const value = (name: string): string | null =>
    argv
      .find((item) => item.startsWith(`--${name}=`))
      ?.slice(name.length + 3) ?? null;

  const limit = Number(value("limit") ?? 300);
  const corpusVersion =
    value("corpus-version") ??
    `hadeethenc-fr-${new Date().toISOString().slice(0, 10)}`;

  if (!Number.isInteger(limit) || limit < 1 || limit > 5_000) {
    throw new Error(
      "--limit doit être un entier compris entre 1 et 5000.",
    );
  }

  const importRequested = argv.includes("--import");
  const validateOnly = argv.includes("--validate-only");

  if (importRequested && validateOnly) {
    throw new Error(
      "--import et --validate-only ne peuvent pas être utilisés ensemble.",
    );
  }

  return {
    limit,
    corpusVersion,
    import: importRequested,
    validateOnly,
    output:
      value("output") ??
      join(
        process.cwd(),
        "scripts/hadith/data/hadeethenc-pilot.payload.json",
      ),
    cache:
      value("cache") ??
      join(tmpdir(), "oummah-hadeethenc-cache.json"),
    mapping:
      value("mapping") ??
      join(
        process.cwd(),
        "scripts/hadith/data/hadeethenc-theme-mapping.json",
      ),
    lifecycleAuthor: value("lifecycle-author"),
    lifecycleJustification: value("lifecycle-justification"),
    lifecycleEvidence: value("lifecycle-evidence"),
  };
}

async function readJsonFile(path: string): Promise<unknown> {
  const raw = await readFile(path, "utf8");
  return JSON.parse(raw) as unknown;
}

async function loadCache(path: string): Promise<JsonObject> {
  try {
    return asObject(await readJsonFile(path));
  } catch {
    return {};
  }
}

async function saveJson(path: string, value: unknown): Promise<void> {
  await mkdir(dirname(path), { recursive: true });
  await writeFile(path, `${JSON.stringify(value, null, 2)}\n`, "utf8");
}

async function fetchJson(
  url: string,
  cache: JsonObject,
): Promise<unknown> {
  const cached = cache[url];
  if (cached !== undefined) {
    return cached;
  }

  let lastError: unknown;

  for (let attempt = 1; attempt <= MAX_RETRIES; attempt += 1) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), TIMEOUT_MS);

    try {
      const response = await fetch(url, {
        signal: controller.signal,
        headers: { Accept: "application/json" },
      });
      const raw = await response.text();

      if (!response.ok) {
        throw new Error(`HadeethEnc ${response.status}: ${url}`);
      }

      const parsed = JSON.parse(raw) as unknown;
      cache[url] = parsed;
      return parsed;
    } catch (error) {
      lastError = error;

      if (attempt < MAX_RETRIES) {
        await sleep(500 * attempt);
      }
    } finally {
      clearTimeout(timer);
    }
  }

  throw lastError instanceof Error
    ? lastError
    : new Error(`Erreur réseau HadeethEnc: ${url}`);
}

function extractRows(payload: unknown): JsonObject[] {
  if (Array.isArray(payload)) {
    return payload.map(asObject);
  }

  const object = asObject(payload);
  const data = object.data;

  return Array.isArray(data) ? data.map(asObject) : [];
}

function hasNextPage(
  payload: unknown,
  page: number,
  rowCount: number,
  pageSize: number,
): boolean {
  const object = asObject(payload);
  const meta = asObject(object.meta);

  const lastPage = Number(
    meta.last_page ??
      object.last_page ??
      object.lastPage ??
      Number.NaN,
  );

  if (Number.isFinite(lastPage)) {
    return page < lastPage;
  }

  const nextPage =
    meta.next_page_url ??
    object.next_page_url ??
    object.nextPageUrl;

  if (typeof nextPage === "string" && nextPage.trim()) {
    return true;
  }

  return rowCount >= pageSize;
}

async function fetchAllPages(
  makeUrl: (page: number) => string,
  cache: JsonObject,
  pageSize: number,
  maxPages = 10_000,
): Promise<JsonObject[]> {
  const rows: JsonObject[] = [];

  for (let page = 1; page <= maxPages; page += 1) {
    const payload = await fetchJson(makeUrl(page), cache);
    const pageRows = extractRows(payload);
    rows.push(...pageRows);

    if (!hasNextPage(payload, page, pageRows.length, pageSize)) {
      return rows;
    }
  }

  throw new Error("Pagination HadeethEnc anormalement longue.");
}

function normalizeCategory(
  rawCategory: unknown,
  categoryById: Map<string, JsonObject>,
  retrievedAt: string,
): SourceCategory | null {
  const rawObject = asObject(rawCategory);
  const id =
    cleanText(rawObject.id) ??
    cleanText(rawCategory);

  if (!id) {
    return null;
  }

  const source = categoryById.get(id) ?? {};
  const label =
    cleanText(rawObject.title) ??
    cleanText(rawObject.label) ??
    cleanText(source.title) ??
    cleanText(source.label);

  if (!label) {
    return null;
  }

  const sourceCount = source.hadeeths_count;

  return {
    sourceCategoryId: id,
    sourceCategoryLabel: label,
    language: "fr",
    parentSourceCategoryId: cleanText(source.parent_id),
    sourceHadeethsCount:
      sourceCount === null || sourceCount === undefined
        ? null
        : Number(sourceCount),
    retrievedAt,
  };
}

function documentaryHashInput(
  record: Omit<HadeethEncRecord, "documentHash" | "retrievedAt">,
): unknown {
  return {
    ...record,
    categories: record.categories.map(
      ({ retrievedAt: _retrievedAt, ...category }) => category,
    ),
  };
}

function validatePayload(payload: Payload): string[] {
  const errors: string[] = [];
  const seenIds = new Set<string>();

  if (!payload.source.corpusVersion.trim()) {
    errors.push("source.corpusVersion est vide.");
  }

  if (payload.records.length < 1) {
    errors.push("Aucune fiche HadeethEnc n'a été préparée.");
  }

  for (const [index, record] of payload.records.entries()) {
    if (!record.sourceHadithId.trim()) {
      errors.push(`records[${index}].sourceHadithId est vide.`);
    }

    if (seenIds.has(record.sourceHadithId)) {
      errors.push(
        `Identifiant HadeethEnc dupliqué: ${record.sourceHadithId}.`,
      );
    }
    seenIds.add(record.sourceHadithId);

    if (!record.hadeethAr.trim()) {
      errors.push(`records[${index}].hadeethAr est vide.`);
    }

    if (!/^[0-9a-f]{64}$/.test(record.documentHash)) {
      errors.push(`records[${index}].documentHash est invalide.`);
    }

    const categoryIds = new Set<string>();
    for (const category of record.categories) {
      if (categoryIds.has(category.sourceCategoryId)) {
        errors.push(
          `Catégorie ${category.sourceCategoryId} dupliquée pour ${record.sourceHadithId}.`,
        );
      }
      categoryIds.add(category.sourceCategoryId);
    }
  }

  return errors;
}

function splitIntoBatches<T>(items: T[], size: number): T[][] {
  const batches: T[][] = [];

  for (let index = 0; index < items.length; index += size) {
    batches.push(items.slice(index, index + size));
  }

  return batches;
}

async function callImportRpc(
  supabaseUrl: string,
  serviceRoleKey: string,
  payload: Payload,
  args: CliArgs,
): Promise<unknown> {
  const response = await fetch(
    `${supabaseUrl.replace(/\/+$/, "")}/rest/v1/rpc/import_hadeethenc_batch`,
    {
      method: "POST",
      headers: {
        apikey: serviceRoleKey,
        Authorization: `Bearer ${serviceRoleKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        p_payload: payload,
        p_lifecycle_author: args.lifecycleAuthor,
        p_lifecycle_justification: args.lifecycleJustification,
        p_lifecycle_version: args.corpusVersion,
        p_lifecycle_evidence: args.lifecycleEvidence,
      }),
      signal: AbortSignal.timeout(TIMEOUT_MS),
    },
  );

  const body = await response.text();

  if (!response.ok) {
    throw new Error(
      `RPC import_hadeethenc_batch ${response.status}: ${body}`,
    );
  }

  return JSON.parse(body) as unknown;
}

async function main(): Promise<void> {
  const args = parseArgs(process.argv.slice(2));
  const cache = await loadCache(args.cache);
  const retrievedAt = new Date().toISOString();

  const categories = await fetchAllPages(
    (page) =>
      `${API}/categories/list/?language=fr&page=${page}&per_page=100`,
    cache,
    100,
  );

  const categoryById = new Map(
    categories
      .map((category): [string, JsonObject] | null => {
        const id = cleanText(category.id);
        return id ? [id, category] : null;
      })
      .filter(
        (entry): entry is [string, JsonObject] => entry !== null,
      ),
  );

  const hadithIds = new Set<string>();

  for (const category of categories) {
    if (hadithIds.size >= args.limit) {
      break;
    }

    const categoryId = cleanText(category.id);
    if (!categoryId) {
      continue;
    }

    const rows = await fetchAllPages(
      (page) =>
        `${API}/hadeeths/list/?language=fr&category_id=${encodeURIComponent(
          categoryId,
        )}&page=${page}&per_page=100`,
      cache,
      100,
    );

    for (const row of rows) {
      const id = cleanText(row.id);
      if (id) {
        hadithIds.add(id);
      }

      if (hadithIds.size >= args.limit) {
        break;
      }
    }
  }

  const mappingRaw = asObject(await readJsonFile(args.mapping));
  const mappingRules = Array.isArray(mappingRaw.rules)
    ? mappingRaw.rules.map(asObject)
    : [];

  const rulesByCategoryId = new Map(
    mappingRules
      .map((rule): [string, JsonObject] | null => {
        const sourceCategoryId = cleanText(rule.sourceCategoryId);
        return sourceCategoryId
          ? [sourceCategoryId, rule]
          : null;
      })
      .filter(
        (entry): entry is [string, JsonObject] => entry !== null,
      ),
  );

  const records: HadeethEncRecord[] = [];

  for (const id of hadithIds) {
    const detail = asObject(
      await fetchJson(
        `${API}/hadeeths/one/?language=fr&id=${encodeURIComponent(id)}`,
        cache,
      ),
    );

    const hadeethAr = cleanText(detail.hadeeth_ar);
    if (!hadeethAr) {
      throw new Error(
        `La fiche HadeethEnc ${id} ne contient pas de texte arabe.`,
      );
    }

    const categoryList = Array.isArray(detail.categories)
      ? detail.categories
      : [];

    const categoriesForRecord = categoryList
      .map((category) =>
        normalizeCategory(category, categoryById, retrievedAt),
      )
      .filter(
        (category): category is SourceCategory => category !== null,
      );

    const themes: ThemeProposal[] = [];

    for (const category of categoriesForRecord) {
      const rule = rulesByCategoryId.get(category.sourceCategoryId);
      const status = cleanText(rule?.status);

      if (status !== "exact" && status !== "certain") {
        continue;
      }

      const targets = Array.isArray(rule?.targetStableKeys)
        ? rule.targetStableKeys
        : [];

      for (const target of targets) {
        const stableKey = cleanText(target);
        if (!stableKey) {
          continue;
        }

        themes.push({
          stableKey,
          status,
          sourceCategoryId: category.sourceCategoryId,
          sourceCategoryLabel: category.sourceCategoryLabel,
        });
      }
    }

    const recordWithoutHash: Omit<
      HadeethEncRecord,
      "documentHash"
    > = {
      sourceHadithId: id,
      sourceUrl: `https://hadeethenc.com/fr/browse/hadith/${id}`,
      title: cleanText(detail.title),
      hadeethAr,
      hadeeth: cleanText(detail.hadeeth),
      hadeethIntro: cleanText(detail.hadeeth_intro),
      hadeethIntroAr: cleanText(detail.hadeeth_intro_ar),
      attribution: cleanText(detail.attribution),
      attributionAr: cleanText(detail.attribution_ar),
      grade: cleanText(detail.grade),
      gradeAr: cleanText(detail.grade_ar),
      explanation: cleanText(detail.explanation),
      explanationAr: cleanText(detail.explanation_ar),
      hints: asArray(detail.hints),
      hintsAr: asArray(detail.hints_ar),
      wordsMeaningsAr: asArray(detail.words_meanings_ar),
      sourceReference: cleanText(detail.source_reference),
      categories: categoriesForRecord,
      themes,
      retrievedAt,
    };

    const { retrievedAt: _retrievedAt, ...hashableRecord } =
      recordWithoutHash;

    const record: HadeethEncRecord = {
      ...recordWithoutHash,
      documentHash: sha256(
        documentaryHashInput(hashableRecord),
      ),
    };

    records.push(record);
  }

  const payload: Payload = {
    source: {
      name: "HadeethEnc",
      organization: "HadeethEnc",
      officialUrl: "https://hadeethenc.com/fr",
      termsUrl: "https://hadeethenc.com/fr",
      language: "fr",
      corpusVersion: args.corpusVersion,
      attribution: "HadeethEnc.com",
      license: null,
    },
    records,
  };

  const validationErrors = validatePayload(payload);

  await saveJson(args.cache, cache);
  await saveJson(args.output, payload);

  console.log(
    JSON.stringify(
      {
        output: args.output,
        records: payload.records.length,
        categories: categories.length,
        cache: args.cache,
        dryRun: !args.import,
        validateOnly: args.validateOnly,
        validationErrors,
      },
      null,
      2,
    ),
  );

  if (validationErrors.length > 0) {
    throw new Error(
      `Validation locale échouée (${validationErrors.length} erreur(s)).`,
    );
  }

  if (!args.import || args.validateOnly) {
    return;
  }

  if (
    ![
      args.lifecycleAuthor,
      args.lifecycleJustification,
      args.lifecycleEvidence,
    ].every((value) => value?.trim())
  ) {
    throw new Error(
      "Contexte lifecycle incomplet; aucun appel RPC n'a été effectué.",
    );
  }

  const supabaseUrl = process.env.SUPABASE_URL;
  const serviceRoleKey = process.env.SUPABASE_SERVICE_ROLE_KEY;

  if (!supabaseUrl || !serviceRoleKey) {
    throw new Error(
      "SUPABASE_URL et SUPABASE_SERVICE_ROLE_KEY sont obligatoires.",
    );
  }

  const batches = splitIntoBatches(payload.records, MAX_RPC_BATCH);
  const results: unknown[] = [];

  for (const [index, batch] of batches.entries()) {
    const batchPayload: Payload = {
      source: payload.source,
      records: batch,
    };

    const result = await callImportRpc(
      supabaseUrl,
      serviceRoleKey,
      batchPayload,
      args,
    );

    results.push(result);

    console.log(
      JSON.stringify(
        {
          batch: index + 1,
          batches: batches.length,
          records: batch.length,
          result,
        },
        null,
        2,
      ),
    );
  }

  console.log(
    JSON.stringify(
      {
        status: "success",
        batches: batches.length,
        records: payload.records.length,
        results,
      },
      null,
      2,
    ),
  );
}

main().catch((error: unknown) => {
  console.error(
    error instanceof Error ? error.message : String(error),
  );
  process.exitCode = 1;
});
