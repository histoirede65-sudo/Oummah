# Importeur Sahih al-Bukhari

Cet importeur lit exclusivement un JSON local contenant le texte arabe, la traduction française, l’explication française et les enseignements français ordonnés. Il ne télécharge rien, ne scrappe aucun site, n’utilise aucune IA et ne génère aucun contenu.

## Commandes

Dry-run :

```powershell
npx.cmd tsx scripts/hadith/import-bukhari.ts --file=scripts/hadith/data/bukhari-sample.json --limit=20 --dry-run --corpus-version=bukhari-v1
```

Import réel — à ne lancer qu’après accord explicite :

```powershell
npx.cmd tsx scripts/hadith/import-bukhari.ts --file=scripts/hadith/data/bukhari-sample.json --limit=20 --corpus-version=bukhari-v1
```

`--file` est obligatoire. `--limit` est un entier positif et limite le nombre de hadiths. `--corpus-version` est obligatoire. Le dry-run n’exige aucune variable Supabase.

L’import réel exige `SUPABASE_URL` et `SUPABASE_SERVICE_ROLE_KEY`. Ces variables ne doivent jamais être affichées. Les écritures passent par l’unique RPC transactionnelle `import_hadith_batch`; le script n’effectue plus de séquence d’écritures REST.

La RPC exige aussi les options `--lifecycle-author`, `--lifecycle-justification`, `--lifecycle-evidence`, `--source-hadith-id-justification` et `--source-hadith-id-evidence`. `--corpus-version` fournit la version du contexte de cycle de vie. Tous ces éléments sont transmis à la transaction et les nouvelles ressources restent `Importée`.

## Format JSON

Le fichier contient `source`, `collection` et `hadiths[]`. Pour l’appel RPC, `source` doit également contenir `sourceId` et `sourceVersionId` (UUID documentaires fournis par le registre), ainsi que `attribution` et `license`. Chaque hadith doit fournir `globalNumber`, `book.number`, `book.sourceId`, `hadithNumberInBook` et `arabicText`; `sourceHadithId` est conservé lorsqu’il est fourni par la source et n’est jamais généré. `chapter` est facultatif. `translationFrench`, `explanationFrench` et `lessonsFrench` sont facultatifs, mais leurs textes et sources sont obligatoires lorsqu’ils sont présents. Une traduction doit aussi documenter `license` et `attribution`.

Les champs de provenance sont conservés : nom, URL, licence, référence, identifiant source, version et statut de vérification. Les statuts sont `unverified`, `partially_verified` ou `verified`.

## Validation et idempotence

Le script refuse les champs anglais, les textes vides, les numéros invalides, les statuts inconnus, les ordres de leçons dupliqués et les doublons de clés structurées. Les hashes SHA-256 sont déterministes et en minuscules. Les textes ne servent jamais de clé d’identité.

La RPC utilise `source_version_id + source_hadith_id` lorsque l’identifiant source existe, avec un repli contrôlé sur la clé de collection et le numéro global. Elle ne modifie jamais une ligne existante et les contenus manquants ne créent aucune ligne vide. Toute erreur annule la transaction entière; une relance identique retourne les ressources existantes sans nouvel événement de cycle de vie.

Le dry-run affiche le fichier, le hash global, les compteurs, erreurs, avertissements, doublons et les trois premiers objets normalisés. Aucun faux corpus n’est fourni par ce dépôt.

## Limites

Le projet ne contient actuellement ni `tsx` ni `@supabase/supabase-js`; le script utilise donc les API natives Node et `fetch`, mais l’exécution nécessite toujours un exécuteur TypeScript disponible. Le script n’a pas été lancé pendant cette mission.

La colonne SQL générée `source_item_id_normalized` normalise `null` en chaîne vide. Les upserts PostgREST utilisent les clés classiques contenant cette colonne générée, sans jamais l’écrire directement.

Chaque appel réseau possède un timeout de 30 secondes. Les réponses HTTP, JSON, erreurs Supabase et cardinalités inattendues sont refusées.

La publication n’est jamais activée par cette RPC. La validation technique ne remplace pas la validation juridique et documentaire, et aucune ressource `Importée` n’est visible dans la vue publique.

Pour compiler sans modifier `package.json` :

```powershell
npx.cmd tsc --outDir .tmp/hadith-build --module commonjs --target ES2022 --moduleResolution node --strict --skipLibCheck scripts/hadith/types.ts scripts/hadith/import-bukhari.ts
node .tmp/hadith-build/import-bukhari.js --file=... --limit=20 --dry-run --corpus-version=bukhari-v1
```

## Validation seule

```powershell
npx.cmd tsx scripts/hadith/import-bukhari.ts --file=scripts/hadith/data/bukhari-pilot.real.json --limit=20 --validate-only --corpus-version=bukhari-v1
```

Cette commande lit le fichier, exécute le Validation Engine, affiche le rapport et n’instancie aucun client Supabase. Le code de sortie est `0` sans `ERROR`, et non nul lorsqu’une `ERROR` est détectée. Les `WARNING` et `INFO` sont affichés sans bloquer la poursuite.

Le fichier `bukhari-pilot.real.json` doit être fourni manuellement depuis une source juridiquement, éditorialement et documentairment validée. Il n’est pas créé par le dépôt. Aucun contenu religieux ne doit être généré, traduit ou complété par IA. Une validation technique réussie ne remplace pas la validation juridique et documentaire de la source.

## Référentiel initial des thèmes OUMMAH

Le fichier `data/oummah-themes.catalog.json` contient uniquement la taxonomie de navigation OUMMAH. Il ne contient aucun hadith, aucune citation et aucune association hadith-thème.

Le catalogue initial comprend 18 thèmes principaux et 90 sous-thèmes. Les clés `stableKey` et les `slug` sont stables et indépendants des recueils. Les traductions françaises sont stockées dans `translations.fr`.

Les catégories provenant de HadeethEnc ou d’une autre source ne définissent jamais cette hiérarchie. Elles pourront seulement être conservées comme provenance lors d’une association ultérieure.

Le champ facultatif `learningPriority` est réservé aux futurs parcours pédagogiques de Wasil. Il peut être absent ou `null`, mais il n’est actuellement utilisé ni pour la navigation, ni pour la publication, ni pour le classement des hadiths.

Validation locale :

```powershell
npx.cmd tsx scripts/hadith/validate-theme-catalog.ts
```

Le validateur contrôle les clés, les slugs, les parents, les cycles, la hiérarchie, les statuts, les versions, les ordres, les traductions françaises, les priorités numériques et l’absence de contenu source dans les descriptions.

## Pilote local de correspondance des catégories

Le mapping `data/hadeethenc-theme-mapping.json` est multi-sources. L’identité d’une règle est `sourceName + ruleId`. Les champs facultatifs `reviewedBy`, `reviewedAt` et `notes` documentent la validation éditoriale sans déclencher de logique.

Les statuts de correspondance sont `exact`, `certain`, `ambiguous` et `unmapped`. Une règle conserve l’identifiant, le libellé et la langue de la catégorie source, ainsi que la règle, la confiance, les thèmes ciblés et le statut de validation.

L’échantillon `data/hadeethenc-theme-pilot.sample.json` est volontairement vide tant qu’aucune fiche HadeethEnc locale riche avec catégories structurées n’a été fournie. Aucune catégorie ni aucun hadith n’est inventé.

Validation du mapping :

```powershell
npx.cmd tsx scripts/hadith/validate-hadeethenc-theme-mapping.ts
```

Rapport local :

```powershell
npx.cmd tsx scripts/hadith/map-hadeethenc-themes.ts --file=scripts/hadith/data/hadeethenc-theme-pilot.sample.json --mapping=scripts/hadith/data/hadeethenc-theme-mapping.json --themes=scripts/hadith/data/oummah-themes.catalog.json
```

Ces commandes ne lancent aucune migration, RPC, écriture Supabase ou import distant.

## Corpus pilote de 20 hadiths

Le gabarit [data/bukhari-pilot.template.json](data/bukhari-pilot.template.json) est volontairement vide : il ne contient aucun texte religieux réel ou fictif. Les données ne doivent être ajoutées qu’après validation de chacun des points suivants :

1. identité exacte de la source ;
2. autorisation de réutilisation ;
3. langue disponible ;
4. numérotation utilisée ;
5. absence de modification du texte ;
6. provenance de chaque champ ;
7. cohérence arabe/français ;
8. présence ou absence d’explication ;
9. présence ou absence d’enseignements ;
10. version du corpus.

| Élément | Source envisagée | URL ou référence | Langue | Licence ou autorisation | Numérotation | Modifications interdites | Attribution requise | Statut de validation | Notes |
|---|---|---|---|---|---|---|---|---|---|
| Texte arabe |  |  |  |  |  |  |  |  |  |
| Titres des livres |  |  |  |  |  |  |  |  |  |
| Titres des chapitres |  |  |  |  |  |  |  |  |  |
| Traduction française |  |  |  |  |  |  |  |  |  |
| Explication française |  |  |  |  |  |  |  |  |  |
| Enseignements français |  |  |  |  |  |  |  |  |  |
| Authenticité |  |  |  |  |  |  |  |  |  |
| Narrateur |  |  |  |  |  |  |  |  |  |
| Références |  |  |  |  |  |  |  |  |  |

### Règles de constitution

Les 20 premiers éléments doivent former un lot technique contrôlé, et ne doivent pas être choisis uniquement par thème. Il est préférable d’utiliser une séquence continue d’une numérotation officielle afin de vérifier les livres, chapitres et références.

Aucune traduction automatique, explication par IA ou leçon par IA n’est autorisée. Un champ facultatif doit rester absent lorsqu’aucune source validée ne le fournit. Des textes provenant de deux éditions différentes ne doivent jamais être fusionnés silencieusement. Toute différence de numérotation doit être documentée. Chaque source doit disposer d’un `sourceItemId` stable lorsqu’il est disponible.
### Import documentaire HadeethEnc

Le flux HadeethEnc conserve `public.hadiths` comme identité Hadith unique. Il ne crée aucun recueil, livre, chapitre ou numéro absent de la source.

La migration utilisée est :

```text
supabase/migrations/20260729000800_hadith_unstructured_sources.sql
```

La RPC dédiée est :

```text
public.import_hadeethenc_batch
```

La RPC historique `public.import_hadith_batch` reste inchangée et continue de servir les corpus structurés.

### Données conservées

La ligne principale `public.hadiths` conserve notamment :

- le texte arabe ;
- l’identifiant HadeethEnc ;
- la source et sa version ;
- l’URL et la référence ;
- l’attribution et le grade français ;
- le statut `Importée`.

La table enfant `hadith_documentary_metadata` conserve les champs propres à HadeethEnc :

- titre ;
- traduction française ;
- introductions française et arabe ;
- attributions française et arabe ;
- grades français et arabe ;
- explications française et arabe ;
- `hints` français et arabes ;
- sens des mots arabes ;
- date de récupération ;
- hash documentaire ;
- référence source.

Les `hints` restent des données source non validées. Ils ne deviennent jamais automatiquement des enseignements OUMMAH.

Les catégories HadeethEnc sont conservées séparément dans :

```text
hadith_source_categories
hadith_source_category_assignments
```

Elles ne remplacent jamais la taxonomie OUMMAH.

Les mappings `exact` et `certain` créent uniquement des propositions :

```text
association_origin = automatic_unvalidated
validation_status = unvalidated
```

Les mappings `ambiguous` et `unmapped` ne créent aucune association thématique.

### Hash et idempotence

Le hash SHA-256 couvre le contenu documentaire stable de la fiche. Il exclut volontairement la date de récupération afin qu’une relance identique ne provoque pas de faux conflit.

L’identité d’import est :

```text
source_version_id + source_hadith_id
```

Une relance identique retourne la ressource existante.

Un même identifiant avec un hash différent provoque :

```text
DOCUMENTARY_CONFLICT
```

Le lot RPC est entièrement annulé en cas d’erreur.

### Préparation locale / dry-run

Cette commande récupère, valide et écrit le payload local sans écrire dans Supabase :

```powershell
npx.cmd tsx scripts/hadith/import-hadeethenc.ts `
  --limit=300 `
  --corpus-version=hadeethenc-fr-v1
```

Le payload est écrit par défaut dans :

```text
scripts/hadith/data/hadeethenc-pilot.payload.json
```

Le cache est placé par défaut dans le répertoire temporaire du système.

### Validation seule

Cette commande prépare les données, exécute toutes les validations locales et n’appelle pas Supabase :

```powershell
npx.cmd tsx scripts/hadith/import-hadeethenc.ts `
  --limit=300 `
  --corpus-version=hadeethenc-fr-v1 `
  --validate-only
```

### Import réel

À ne lancer qu’après validation juridique, documentaire et SQL explicite :

```powershell
npx.cmd tsx scripts/hadith/import-hadeethenc.ts `
  --limit=300 `
  --corpus-version=hadeethenc-fr-v1 `
  --import `
  --lifecycle-author="..." `
  --lifecycle-justification="..." `
  --lifecycle-evidence="..."
```

L’import réel exige :

```text
SUPABASE_URL
SUPABASE_SERVICE_ROLE_KEY
```

Aucun secret n’est écrit en dur ou affiché.

Le script découpe automatiquement les données en lots de 50 fiches maximum, conformément à la limite de la RPC.

### Options utiles

```text
--output=<chemin>
--cache=<chemin>
--mapping=<chemin>
--limit=<1..5000>
--corpus-version=<version>
--validate-only
--import
```

Le fichier de mapping est obligatoire et doit exister :

```text
scripts/hadith/data/hadeethenc-theme-mapping.json
```

### Validation TypeScript

```powershell
npx.cmd tsc --noEmit `
  --module commonjs `
  --target ES2022 `
  --moduleResolution node `
  --strict `
  --skipLibCheck `
  scripts/hadith/import-hadeethenc.ts
```

### Sécurité avant déploiement

Avant toute application distante :

1. appliquer la migration sur une base locale ou de validation dédiée ;
2. vérifier les anciennes importations structurées ;
3. tester un import documentaire minimal ;
4. tester une seconde exécution identique ;
5. tester `DOCUMENTARY_CONFLICT` ;
6. vérifier le rollback intégral ;
7. vérifier que `anon` et `authenticated` ne peuvent pas appeler la RPC ;
8. vérifier qu’aucune ressource `Importée` n’est visible publiquement ;
9. vérifier les policies RLS et les vues publiques ;
10. ne lancer aucun import réel tant que la licence d’utilisation et de redistribution HadeethEnc n’est pas validée.

### Limite documentaire importante

La migration conserve la traduction et l’explication françaises dans `hadith_documentary_metadata` pendant la phase d’import et de validation. Elle ne les publie pas automatiquement dans les tables éditoriales finales. Cette séparation évite d’assimiler un contenu source importé à une traduction ou une explication OUMMAH déjà validée.
