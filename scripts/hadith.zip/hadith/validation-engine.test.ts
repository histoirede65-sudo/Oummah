import { strict as assert } from 'node:assert';
import { validateCorpus, type ValidationCorpus } from './validation-engine';

const validHadith = (overrides: Record<string, unknown> = {}): Record<string, unknown> => ({
  id: 'bukhari-1', collectionId: 'bukhari', bookId: 'book-1', bookNumber: 1, bookName: 'Book', chapterId: 'chapter-1', chapterNumber: 1, chapterTitle: 'Chapter', globalNumber: 1, hadithNumberInBook: 1, arabicText: 'Arabic text', narrator: 'Narrator', authenticity: 'sahih', source: 'Source', sourceReference: 'Reference', version: 'v1', license: 'public-domain', ...overrides,
});

const report = (hadiths: Record<string, unknown>[]): ReturnType<typeof validateCorpus> => validateCorpus({ version: 'v1', license: 'public-domain', hadiths } as ValidationCorpus);

const perfect = report([validHadith()]);
assert.equal(perfect.canImport, true);
assert.equal(perfect.errors, 0);

const duplicate = report([validHadith(), validHadith({ globalNumber: 2 })]);
assert.equal(duplicate.duplicates.some((item) => item.code === 'DUPLICATE_ID'), true);
assert.equal(duplicate.canImport, false);

const gap = report([validHadith(), validHadith({ id: 'bukhari-3', sourceHadithId: 'bukhari-3', globalNumber: 3 })]);
assert.equal(gap.gaps.some((item) => item.value === 2), true);
assert.equal(gap.canImport, true);

for (const field of ['arabicText', 'narrator', 'sourceReference', 'license'] as const) {
  const overrides: Record<string, unknown> = { [field]: '' };
  const result = report([validHadith(overrides)]);
  assert.equal(result.canImport, false, `${field} doit bloquer l'import`);
}

const brokenOrder = report([validHadith({ globalNumber: 2 }), validHadith({ id: 'bukhari-1b', globalNumber: 1 })]);
assert.equal(brokenOrder.inconsistencies.some((item) => item.code === 'NUMBERING_INVERSION'), true);

const missingTranslationMetadata = report([validHadith({ translationFrench: { text: 'French text' } })]);
assert.equal(missingTranslationMetadata.canImport, false);

console.log('Validation Engine V1: tests réussis');
