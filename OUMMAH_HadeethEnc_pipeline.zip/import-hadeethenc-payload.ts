import { createHash } from "node:crypto";
import { readFile, writeFile } from "node:fs/promises";
import { resolve } from "node:path";

type JsonObject = Record<string, unknown>;
type Payload = { source: JsonObject; records: JsonObject[] };

const MAX_BATCH = 50;
const TIMEOUT_MS = 30_000;
const STATE_FILE = ".hadeethenc-import-state.json";

function arg(name: string): string | null {
  const prefix = `--${name}=`;
  return process.argv.slice(2).find((value) => value.startsWith(prefix))?.slice(prefix.length) ?? null;
}

function text(value: unknown): string {
  return typeof value === "string" ? value.trim() : "";
}

function sha256(value: string): string {
  return createHash("sha256").update(value, "utf8").digest("hex");
}

function validate(payload: Payload): string[] {
  const errors: string[] = [];
  const ids = new Set<string>();

  if (!payload || typeof payload !== "object") return ["Payload JSON invalide."];
  if (!Array.isArray(payload.records)) return ["records doit être un tableau."];
  if (!text(payload.source?.corpusVersion)) errors.push("source.corpusVersion est vide.");

  payload.records.forEach((record, index) => {
    const id = text(record.sourceHadithId);
    if (!id) errors.push(`records[${index}].sourceHadithId est vide.`);
    if (ids.has(id)) errors.push(`Identifiant dupliqué: ${id}.`);
    ids.add(id);
    if (!text(record.hadeethAr)) errors.push(`${id || index}: texte arabe vide.`);
    if (!text(record.hadeeth)) errors.push(`${id || index}: traduction française vide.`);
    if (!text(record.explanation)) errors.push(`${id || index}: explication française vide.`);
    if (!/^[0-9a-f]{64}$/.test(text(record.documentHash))) errors.push(`${id || index}: hash documentaire invalide.`);
  });

  return errors;
}

function batches<T>(rows: T[], size: number): T[][] {
  const result: T[][] = [];
  for (let index = 0; index < rows.length; index += size) result.push(rows.slice(index, index + size));
  return result;
}

async function rpc(url: string, key: string, payload: Payload, lifecycle: Record<string, string>): Promise<unknown> {
  const response = await fetch(`${url.replace(/\/+$/, "")}/rest/v1/rpc/import_hadeethenc_batch`, {
    method: "POST",
    headers: { apikey: key, Authorization: `Bearer ${key}`, "Content-Type": "application/json" },
    body: JSON.stringify({
      p_payload: payload,
      p_lifecycle_author: lifecycle.author,
      p_lifecycle_justification: lifecycle.justification,
      p_lifecycle_version: text(payload.source.corpusVersion),
      p_lifecycle_evidence: lifecycle.evidence,
    }),
    signal: AbortSignal.timeout(TIMEOUT_MS),
  });
  const body = await response.text();
  if (!response.ok) throw new Error(`RPC import_hadeethenc_batch ${response.status}: ${body}`);
  return body ? JSON.parse(body) : null;
}

async function main(): Promise<void> {
  const file = resolve(arg("file") ?? "scripts/hadith/data/hadeethenc-fr-v1.17.0.payload.json");
  const shouldImport = process.argv.includes("--import");
  const dryRun = process.argv.includes("--dry-run") || !shouldImport;
  const raw = await readFile(file, "utf8");
  const payload = JSON.parse(raw) as Payload;
  const errors = validate(payload);

  const report = {
    file,
    payloadSha256: sha256(raw),
    records: payload.records.length,
    arabic: payload.records.filter((r) => text(r.hadeethAr)).length,
    french: payload.records.filter((r) => text(r.hadeeth)).length,
    explanations: payload.records.filter((r) => text(r.explanation)).length,
    benefits: payload.records.filter((r) => Array.isArray(r.hints) && r.hints.length > 0).length,
    mode: dryRun ? "dry-run" : "import",
    errors,
  };
  console.log(JSON.stringify(report, null, 2));
  if (errors.length) throw new Error(`Validation échouée: ${errors.length} erreur(s).`);
  if (dryRun) return;

  const url = process.env.SUPABASE_URL;
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY;
  const lifecycle = {
    author: arg("lifecycle-author") ?? "",
    justification: arg("lifecycle-justification") ?? "",
    evidence: arg("lifecycle-evidence") ?? "",
  };
  if (!url || !key) throw new Error("SUPABASE_URL et SUPABASE_SERVICE_ROLE_KEY sont obligatoires.");
  if (!lifecycle.author || !lifecycle.justification || !lifecycle.evidence) {
    throw new Error("Contexte lifecycle incomplet. Aucun import n'a été lancé.");
  }

  const chunks = batches(payload.records, MAX_BATCH);
  let completedBatches = 0;
  try {
    const state = JSON.parse(await readFile(STATE_FILE, "utf8")) as { payloadSha256?: string; completedBatches?: number };
    if (state.payloadSha256 === sha256(raw)) completedBatches = Number(state.completedBatches ?? 0);
  } catch { completedBatches = 0; }
  for (const [index, records] of chunks.entries()) {
    if (index < completedBatches) {
      console.log(JSON.stringify({ batch: index + 1, skipped: true }, null, 2));
      continue;
    }
    const result = await rpc(url, key, { source: payload.source, records }, lifecycle);
    console.log(JSON.stringify({ batch: index + 1, totalBatches: chunks.length, records: records.length, result }, null, 2));
    await writeFile(STATE_FILE, JSON.stringify({ payloadSha256: sha256(raw), completedBatches: index + 1, totalBatches: chunks.length }, null, 2), "utf8");
  }
  await writeFile(STATE_FILE, JSON.stringify({ payloadSha256: sha256(raw), completedBatches: chunks.length, totalBatches: chunks.length, completedAt: new Date().toISOString() }, null, 2), "utf8");
}

main().catch((error: unknown) => {
  console.error(error instanceof Error ? error.message : String(error));
  process.exitCode = 1;
});
