import { Ionicons } from '@expo/vector-icons';
import type { Href } from 'expo-router';
import { router } from 'expo-router';
import { Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';

import { useGlobalAudioPlayer } from '../../context/AudioPlayerProvider';
import { useReciter } from '../../context/ReciterProvider';
import { getTrackSurahId, type AudioTrack } from '../../core/audio';
import { SURAHS } from '../../data/surahs';
import { ListeningHeader, ReciterCard, SectionHeader, TrackCard, listeningStyles } from '../../features/audio/presentation/ListeningComponents';
import { useListeningHomeViewModel } from '../../features/audio/presentation/viewmodels/useListeningHomeViewModel';
import { useI18n } from '../../i18n';
import { colors } from '../../theme/colors';
import { typography } from '../../theme/typography';

function openTrack(track: AudioTrack, reciterId: string) {
  const surahId = getTrackSurahId(track);
  if (surahId) router.push(`/listen/${surahId}?reciterId=${reciterId}&returnTo=${encodeURIComponent('/reciters')}` as Href);
}

function formatListeningPosition(seconds: number) {
  const safeSeconds = Math.max(0, Math.floor(seconds));
  return `${String(Math.floor(safeSeconds / 60)).padStart(2, '0')}:${String(safeSeconds % 60).padStart(2, '0')}`;
}

export default function RecitationsScreen() {
  const { t } = useI18n();
  const { currentReciter } = useReciter();
  const { listeningResume, resumeListening, startNewListening } = useGlobalAudioPlayer();
  const { data, loading } = useListeningHomeViewModel();
  const recent = data?.recentlyListened ?? [];
  const downloads = data?.latestDownloads ?? [];
  const favorites = data?.favorites ?? [];
  const resumeSurah = listeningResume
    ? SURAHS.find((surah) => surah.id === listeningResume.surahId)
    : null;
  const continueListening = listeningResume ?? data?.continueListening ?? null;

  const resume = async () => {
    const session = await resumeListening();
    if (session) router.push(`/listen/${session.surahId}?reciterId=${session.reciterId}&returnTo=${encodeURIComponent('/reciters')}` as Href);
    else if (data?.continueListening && currentReciter) openTrack(data.continueListening.track, currentReciter.id);
  };

  const startNew = async () => {
    await startNewListening();
    router.push('/listen/surahs');
  };

  return (
    <SafeAreaView edges={['top']} style={listeningStyles.safeArea}>
      <ScrollView contentContainerStyle={listeningStyles.content} showsVerticalScrollIndicator={false}>
        <ListeningHeader title={t('recitations.title')} subtitle={t('recitations.subtitle')} onAction={() => router.push('/listen/playlists')} />

        {loading ? <Text style={listeningStyles.loading}>{t('common.loading')}</Text> : null}

        <SectionHeader title={t('recitations.continueListening')} />
        {continueListening ? (
          <View>
          <Pressable onPress={() => void resume()} style={({ pressed }) => [styles.continueCard, pressed && styles.pressed]}>
            <View style={styles.continueIcon}><Ionicons name="headset" size={27} color={colors.goldMuted} /></View>
            <View style={styles.continueCopy}>
              <Text style={styles.eyebrow}>{t('recitations.resume')}</Text>
              <Text style={styles.continueTitle}>{listeningResume ? resumeSurah?.transliteration ?? t('recitations.surahNumber', { number: listeningResume.surahId }) : data?.continueListening?.track.title}</Text>
              <Text style={styles.continueDetail}>{listeningResume
                ? `${formatListeningPosition(listeningResume.positionSeconds)} · ${currentReciter?.name ?? ''}`
                : t('recitations.positionAndSpeed', { minute: Math.floor((data?.continueListening?.history?.positionSeconds ?? 0) / 60), speed: data?.continueListening?.history?.playbackRate ?? 1 })}</Text>
              <View style={styles.progressTrack}><View style={[styles.progressFill, { width: `${Math.min(96, Math.max(4, ((listeningResume?.positionSeconds ?? data?.continueListening?.history?.positionSeconds) ?? 0) / 6))}%` }]} /></View>
            </View>
            <View style={styles.continuePlay}><Ionicons name="play" size={18} color={colors.background} /></View>
          </Pressable>
          {listeningResume ? (
            <Pressable onPress={() => void startNew()} style={({ pressed }) => [styles.newListening, pressed && styles.pressed]}>
              <Ionicons name="add-circle-outline" size={14} color={colors.textMuted} />
              <Text style={styles.newListeningText}>{t('recitations.startNewListening')}</Text>
            </Pressable>
          ) : null}
          </View>
        ) : <Empty text={t('recitations.noListeningYet')} />}

        <SectionHeader title={t('recitations.recentlyListened')} onPress={() => router.push('/listen/playlists')} actionLabel={t('home.seeAll')} />
        {recent.length ? <Horizontal>{recent.map((item) => <TrackCard key={item.track.id} track={item.track} detail={currentReciter?.name} onPress={() => { if (currentReciter) openTrack(item.track, currentReciter.id); }} />)}</Horizontal> : <Empty text={t('recitations.historyEmpty')} />}

        <SectionHeader title={t('recitations.popularReciters')} onPress={() => router.push({ pathname: '/listen/reciters', params: { returnTo: '/reciters' } })} actionLabel={t('home.seeAll')} />
        <Horizontal>{data?.popularReciters.map((reciter) => <ReciterCard key={reciter.id} reciter={reciter} onPress={() => router.push({ pathname: '/listen/reciter/[reciterId]', params: { reciterId: reciter.id, returnTo: '/reciters' } })} />)}</Horizontal>

        <SectionHeader title={t('recitations.popularSurahs')} onPress={() => router.push('/listen/surahs')} actionLabel={t('home.seeAll')} />
        <Horizontal>{data?.popularSurahs.map((track) => <TrackCard key={track.id} track={track} detail={currentReciter?.name} onPress={() => { if (currentReciter) openTrack(track, currentReciter.id); }} />)}</Horizontal>

        <SectionHeader title={t('recitations.latestDownloads')} onPress={() => router.push('/listen/surahs?filter=downloaded')} actionLabel={t('home.seeAll')} />
        {downloads.length ? <Horizontal>{downloads.map((item) => <TrackCard key={item.track.id} track={item.track} detail={currentReciter?.name} onPress={() => { if (currentReciter) openTrack(item.track, currentReciter.id); }} />)}</Horizontal> : <Empty text={t('recitations.downloadsEmpty')} />}

        <SectionHeader title={t('common.favorites')} onPress={() => router.push('/listen/surahs?filter=favorites')} actionLabel={t('home.seeAll')} />
        {favorites.length ? <Horizontal>{favorites.map((item) => <TrackCard key={item.track.id} track={item.track} detail={currentReciter?.name} onPress={() => { if (currentReciter) openTrack(item.track, currentReciter.id); }} />)}</Horizontal> : <Empty text={t('recitations.favoritesEmpty')} />}

        <SectionHeader title={t('recitations.recommendations')} />
        <Horizontal>{data?.recommendations.map((track) => <TrackCard key={track.id} track={track} detail={currentReciter?.name} onPress={() => { if (currentReciter) openTrack(track, currentReciter.id); }} />)}</Horizontal>
      </ScrollView>
    </SafeAreaView>
  );
}

function Horizontal({ children }: { children: React.ReactNode }) {
  return <ScrollView horizontal contentContainerStyle={listeningStyles.horizontal} showsHorizontalScrollIndicator={false}>{children}</ScrollView>;
}

function Empty({ text }: { text: string }) {
  return <View style={listeningStyles.empty}><Text style={listeningStyles.emptyText}>{text}</Text></View>;
}

const styles = StyleSheet.create({
  continueCard: { minHeight: 112, padding: 14, flexDirection: 'row', alignItems: 'center', borderRadius: 22, borderWidth: 1, borderColor: colors.border, backgroundColor: colors.surfaceAlt },
  continueIcon: { width: 58, height: 76, alignItems: 'center', justifyContent: 'center', borderRadius: 17, backgroundColor: colors.purpleDeep },
  continueCopy: { flex: 1, minWidth: 0, marginHorizontal: 12 },
  eyebrow: { color: colors.goldMuted, fontFamily: typography.sans, fontSize: 7.5, fontWeight: '700', letterSpacing: 1 },
  continueTitle: { marginTop: 2, color: colors.text, fontFamily: typography.serifMedium, fontSize: 20 },
  continueDetail: { color: colors.textMuted, fontFamily: typography.sans, fontSize: 8.5 },
  progressTrack: { height: 3, marginTop: 10, overflow: 'hidden', borderRadius: 2, backgroundColor: colors.surfaceLight },
  progressFill: { height: '100%', backgroundColor: colors.goldMuted },
  continuePlay: { width: 39, height: 39, alignItems: 'center', justifyContent: 'center', borderRadius: 20, backgroundColor: colors.goldMuted },
  newListening: { alignSelf: 'center', minHeight: 30, marginTop: 6, paddingHorizontal: 10, flexDirection: 'row', alignItems: 'center' },
  newListeningText: { marginLeft: 5, color: colors.textMuted, fontFamily: typography.sans, fontSize: 8.5, fontWeight: '500' },
  pressed: { opacity: 0.64 },
});
