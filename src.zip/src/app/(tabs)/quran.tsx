import type { Href } from 'expo-router';
import { router } from 'expo-router';
import { useMemo, useState } from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';

import ContinueListeningCard from '../../components/quran/ContinueListeningCard';
import LastReadingCard from '../../components/quran/LastReadingCard';
import QuranHeader from '../../components/quran/QuranHeader';
import QuranQuickActions, { type QuranTab } from '../../components/quran/QuranQuickActions';
import QuranSearchBar from '../../components/quran/QuranSearchBar';
import SurahList from '../../components/quran/SurahList';
import { useGlobalAudioPlayer } from '../../context/AudioPlayerProvider';
import { SURAHS } from '../../data/surahs';
import { useI18n } from '../../i18n';
import { colors } from '../../theme/colors';
import { typography } from '../../theme/typography';

function normalize(value: string, locale: string) {
  return value.normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLocaleLowerCase(locale);
}

export default function QuranScreen() {
  const { language, t } = useI18n();
  const [query, setQuery] = useState('');
  const [activeTab, setActiveTab] = useState<QuranTab>('surahs');
  const { track } = useGlobalAudioPlayer();

  const filteredSurahs = useMemo(() => {
    if (activeTab !== 'surahs') return [];
    const search = normalize(query.trim(), language);
    if (!search) return SURAHS;

    return SURAHS.filter((surah) =>
      normalize(`${surah.frenchName} ${surah.transliteration} ${surah.arabicName}`, language).includes(search),
    );
  }, [activeTab, language, query]);

  const changeTab = (tab: QuranTab) => {
    setActiveTab(tab);
    if (tab !== 'surahs') setQuery('');
  };

  const emptyMessage = activeTab === 'juz'
    ? t('quran.juzComingSoon')
    : activeTab === 'favorites'
      ? t('quran.favoritesEmpty')
      : t('quran.empty');

  const header = (
    <>
      <QuranHeader
        onMenuPress={() => console.log('Menu Coran')}
        onFavoritePress={() => changeTab('favorites')}
      />
      <LastReadingCard onResume={() => router.push('/surah/2' as Href)} />
      <ContinueListeningCard
        onResume={() => router.push(`/listen/${track?.surahId ?? 1}?returnTo=${encodeURIComponent('/quran')}` as Href)}
        onOpenRecitations={() => router.push('/reciters' as Href)}
      />
      <View style={styles.searchGap}>
        <QuranSearchBar value={query} onChangeText={setQuery} />
      </View>
      <QuranQuickActions
        activeTab={activeTab}
        onTabChange={changeTab}
        onFavoritePress={() => {
          console.log('Favoris');
          changeTab('favorites');
        }}
        onBookmarkPress={() => console.log('Marques-pages')}
        onAudioPress={() => router.push('/reciters' as Href)}
      />
      <View style={styles.listHeading}>
        <Text style={styles.listTitle}>
          {activeTab === 'surahs' ? t('quran.allSurahs') : activeTab === 'juz' ? t('quran.juz') : t('common.favorites')}
        </Text>
        {activeTab === 'surahs' ? <Text style={styles.count}>{filteredSurahs.length} / 114</Text> : null}
      </View>
    </>
  );

  return (
    <SafeAreaView edges={['top']} style={styles.safeArea}>
      <SurahList
        data={filteredSurahs}
        header={header}
        emptyMessage={emptyMessage}
        onSurahPress={(surah) => router.push(`/surah/${surah.id}` as Href)}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: { flex: 1, backgroundColor: colors.background },
  searchGap: { marginTop: 12 },
  listHeading: { marginBottom: 10, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  listTitle: { color: colors.goldLight, fontFamily: typography.serifMedium, fontSize: 21 },
  count: { color: colors.textMuted, fontFamily: typography.sans, fontSize: 10.5, fontWeight: '500' },
});
