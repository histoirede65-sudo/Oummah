import 'react-native-gesture-handler';
import 'react-native-reanimated';

import { Stack } from 'expo-router';
import { GestureHandlerRootView } from 'react-native-gesture-handler';
import { SafeAreaProvider } from 'react-native-safe-area-context';

import { AudioPlayerProvider } from '../context/AudioPlayerProvider';
import { ReciterProvider } from '../context/ReciterProvider';
import { I18nProvider } from '../i18n/I18nProvider';

export default function RootLayout() {
  return (
    <GestureHandlerRootView style={{ flex: 1 }}>
      <SafeAreaProvider>
        <I18nProvider>
          <ReciterProvider>
            <AudioPlayerProvider>
              <Stack
                screenOptions={{
                  headerShown: false,
                  animation: 'fade',
                  animationDuration: 250,
                  contentStyle: {
                    backgroundColor: '#071F1D',
                  },
                }}
              />
            </AudioPlayerProvider>
          </ReciterProvider>
        </I18nProvider>
      </SafeAreaProvider>
    </GestureHandlerRootView>
  );
}