import { Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import type { Href } from 'expo-router';
import { router, useLocalSearchParams } from 'expo-router';
import { useMemo, useState } from 'react';
import { Alert, Pressable, ScrollView, Share, StyleSheet, Text, useWindowDimensions, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';

import SurahHeader from '../../components/surah/SurahHeader';
import VerseCard from '../../components/surah/VerseCard';
import { SURAHS } from '../../data/surahs';
import { AL_FATIHA_VERSES, type Verse } from '../../data/verses/al-fatiha';
import { hapticsService } from '../../core/settings';
import { useI18n } from '../../i18n';
import { colors } from '../../theme/colors';
import { typography } from '../../theme/typography';

export default function SurahReadingScreen() {
  const { t } = useI18n();
  const { id } = useLocalSearchParams<{ id: string }>();
  const { width } = useWindowDimensions();
  const compact = width < 370;
  const surahId = Number(id) || 1;
  const surah = SURAHS.find((item) => item.id === surahId) ?? SURAHS[0];
  const verses = surah.id === 1 ? AL_FATIHA_VERSES : [];
  const [favorites, setFavorites] = useState<Set<number>>(() => new Set());
  const [bookmarks, setBookmarks] = useState<Set<number>>(() => new Set());
  const progress = useMemo(() => Math.min(100, Math.round((4 / surah.verses) * 100)), [surah.verses]);

  const toggleInSet = (
    setter: React.Dispatch<React.SetStateAction<Set<number>>>,
    verse: Verse,
  ) => {
    setter((current) => {
      const next = new Set(current);
      if (next.has(verse.id)) next.delete(verse.id);
      else next.add(verse.id);
      return next;
    });
  };

  return (
    <SafeAreaView edges={['top']} style={styles.safeArea}>
      <ScrollView
        contentContainerStyle={[styles.content, compact && styles.contentCompact]}
        showsVerticalScrollIndicator={false}
      >
        <SurahHeader surah={surah} onBack={() => router.back()} />

        <LinearGradient colors={[colors.surfaceAlt, colors.surface]} style={styles.resumeCard}>
          <View style={styles.resumeIcon}><Ionicons name="bookmark" size={20} color={colors.goldMuted} /></View>
          <View style={styles.resumeCopy}>
            <Text style={styles.resumeCaption}>{t('quran.resumeReading')}</Text>
            <Text style={styles.resumeTitle}>{t('quran.lastVerseRead', { verse: 4 })}</Text>
            <View style={styles.progressTrack}><View style={[styles.progress, { width: `${progress}%` }]} /></View>
          </View>
          <Pressable style={({ pressed }) => [styles.resumeButton, pressed && styles.pressed]}>
            <Ionicons name="arrow-forward" size={18} color={colors.background} />
          </Pressable>
        </LinearGradient>

        <Pressable
          onPress={() => router.push(`/listen/${surah.id}?returnTo=${encodeURIComponent(`/surah/${surah.id}`)}` as Href)}
          style={({ pressed }) => [styles.listenButton, pressed && styles.pressed]}
        >
          <Ionicons name="headset-outline" size={18} color={colors.goldMuted} />
          <Text style={styles.listenButtonText}>{t('quran.listenSurah')}</Text>
          <Ionicons name="chevron-forward" size={15} color={colors.textMuted} />
        </Pressable>

        <View style={styles.sectionHeading}>
          <Text style={styles.sectionTitle}>{t('quran.verses')}</Text>
          <Text style={styles.sectionCount}>{t('common.verseCount', { count: verses.length })}</Text>
        </View>

        {verses.length > 0 ? (
          <View style={styles.verseList}>
            {verses.map((verse) => (
              <VerseCard
                key={verse.id}
                verse={verse}
                isFavorite={favorites.has(verse.id)}
                isBookmarked={bookmarks.has(verse.id)}
                onListen={(item) => Alert.alert(t('quran.listenVerseTitle', { verse: item.id }), t('quran.listenVerseComingSoon'))}
                onTafsir={() => Alert.alert(t('common.tafsir'), t('quran.tafsirComingSoon'))}
                onDalil={() => Alert.alert(t('nav.dalil'), t('quran.dalilComingSoon'))}
                onFavorite={(item) => {
                  toggleInSet(setFavorites, item);
                  void hapticsService.favorite();
                }}
                onBookmark={(item) => {
                  toggleInSet(setBookmarks, item);
                  void hapticsService.bookmark();
                }}
                onShare={(item) => Share.share({ message: `${item.arabic}\n\n${item.french}` })}
              />
            ))}
          </View>
        ) : (
          <View style={styles.placeholder}>
            <Ionicons name="book-outline" size={31} color={colors.goldMuted} />
            <Text style={styles.placeholderTitle}>{surah.transliteration}</Text>
            <Text style={styles.placeholderText}>{t('quran.versesComingSoon')}</Text>
          </View>
        )}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: { flex: 1, backgroundColor: colors.background },
  content: { paddingHorizontal: 16, paddingBottom: 105 },
  contentCompact: { paddingHorizontal: 12 },
  resumeCard: { minHeight: 96, marginTop: 12, padding: 13, flexDirection: 'row', alignItems: 'center', borderRadius: 20, borderWidth: 1, borderColor: colors.border },
  resumeIcon: { width: 47, height: 47, alignItems: 'center', justifyContent: 'center', borderRadius: 15, backgroundColor: colors.purpleDeep },
  resumeCopy: { flex: 1, minWidth: 0, marginHorizontal: 12 },
  resumeCaption: { color: colors.goldMuted, fontFamily: typography.sans, fontSize: 7.5, fontWeight: '700', letterSpacing: 1.1 },
  resumeTitle: { marginTop: 3, color: colors.text, fontFamily: typography.serifMedium, fontSize: 16 },
  progressTrack: { height: 3, marginTop: 10, borderRadius: 2, backgroundColor: colors.surfaceLight },
  progress: { height: '100%', borderRadius: 2, backgroundColor: colors.goldMuted },
  resumeButton: { width: 37, height: 37, alignItems: 'center', justifyContent: 'center', borderRadius: 19, backgroundColor: colors.goldMuted },
  listenButton: { height: 46, marginTop: 10, paddingHorizontal: 14, flexDirection: 'row', alignItems: 'center', borderRadius: 16, borderWidth: 1, borderColor: colors.borderSoft, backgroundColor: colors.purpleDeep },
  listenButtonText: { flex: 1, marginLeft: 9, color: colors.textSecondary, fontFamily: typography.sans, fontSize: 10.5, fontWeight: '600' },
  sectionHeading: { marginTop: 20, marginBottom: 11, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  sectionTitle: { color: colors.goldMuted, fontFamily: typography.serifMedium, fontSize: 21 },
  sectionCount: { color: colors.textMuted, fontFamily: typography.sans, fontSize: 10, fontWeight: '500' },
  verseList: { gap: 11 },
  placeholder: { paddingVertical: 55, paddingHorizontal: 24, alignItems: 'center', borderRadius: 22, borderWidth: 1, borderColor: colors.borderSoft, backgroundColor: colors.surface },
  placeholderTitle: { marginTop: 10, color: colors.text, fontFamily: typography.serifMedium, fontSize: 20 },
  placeholderText: { marginTop: 5, color: colors.textMuted, fontFamily: typography.sans, fontSize: 11, lineHeight: 17, textAlign: 'center' },
  pressed: { opacity: 0.6 },
});
