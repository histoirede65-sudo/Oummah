import { Ionicons } from '@expo/vector-icons';
import type { Href } from 'expo-router';
import { router, useLocalSearchParams } from 'expo-router';
import { useEffect } from 'react';
import { Pressable, ScrollView, StyleSheet, Text, TextInput, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';

import type { SurahFilter, SurahSort } from '../../features/audio/domain/audio';
import { ListeningHeader, SurahAudioRow, listeningStyles } from '../../features/audio/presentation/ListeningComponents';
import { useSurahCatalogViewModel } from '../../features/audio/presentation/viewmodels/useSurahCatalogViewModel';
import { useI18n } from '../../i18n';
import { colors } from '../../theme/colors';
import { typography } from '../../theme/typography';

const filters: readonly SurahFilter[] = ['all', 'favorites', 'downloaded'];
const sorts: readonly SurahSort[] = ['number', 'name', 'verses'];

export default function AudioSurahsScreen() {
  const { t } = useI18n();
  const params = useLocalSearchParams<{ filter?: SurahFilter }>();
  const model = useSurahCatalogViewModel();
  const { setFilter } = model;
  useEffect(() => { if (params.filter && filters.includes(params.filter)) setFilter(params.filter); }, [params.filter, setFilter]);
  return (
    <SafeAreaView edges={['top']} style={listeningStyles.safeArea}>
      <ScrollView contentContainerStyle={listeningStyles.content} keyboardShouldPersistTaps="handled" showsVerticalScrollIndicator={false}>
        <ListeningHeader title={t('quran.surahs')} subtitle={t('recitations.surahsSubtitle')} onBack={() => router.back()} />
        <View style={styles.search}><Ionicons name="search" size={17} color={colors.textMuted} /><TextInput value={model.search} onChangeText={model.setSearch} placeholder={t('quran.search')} placeholderTextColor={colors.textMuted} style={styles.input} /></View>
        <View style={styles.controls}>{filters.map((filter) => <Chip key={filter} active={model.filter === filter} label={t(`recitations.filter.${filter}`)} onPress={() => model.setFilter(filter)} />)}</View>
        <View style={styles.controls}>{sorts.map((sort) => <Chip key={sort} active={model.sort === sort} label={t(`recitations.sort.${sort}`)} onPress={() => model.setSort(sort)} />)}</View>
        <Text style={styles.count}>{t('recitations.resultCount', { count: model.items.length })}</Text>
        {model.loading ? <Text style={listeningStyles.loading}>{t('common.loading')}</Text> : null}
        <View style={styles.list}>{model.items.map((item) => <SurahAudioRow key={item.track.id} item={item} onPress={() => router.push(`/listen/${item.surah.id}?returnTo=${encodeURIComponent('/listen/surahs')}` as Href)} />)}</View>
        {!model.loading && model.items.length === 0 ? <View style={listeningStyles.empty}><Text style={listeningStyles.emptyText}>{t('quran.empty')}</Text></View> : null}
      </ScrollView>
    </SafeAreaView>
  );
}

function Chip({ label, active, onPress }: { label: string; active: boolean; onPress: () => void }) {
  return <Pressable onPress={onPress} style={[styles.chip, active && styles.chipActive]}><Text style={[styles.chipText, active && styles.chipTextActive]}>{label}</Text></Pressable>;
}

const styles = StyleSheet.create({
  search: { height: 44, paddingHorizontal: 13, flexDirection: 'row', alignItems: 'center', borderRadius: 15, borderWidth: 1, borderColor: colors.borderSoft, backgroundColor: colors.surface },
  input: { flex: 1, marginLeft: 8, color: colors.text, fontFamily: typography.sans, fontSize: 10 },
  controls: { marginTop: 10, flexDirection: 'row', gap: 7 },
  chip: { flex: 1, minHeight: 34, paddingHorizontal: 7, alignItems: 'center', justifyContent: 'center', borderRadius: 12, borderWidth: 1, borderColor: colors.borderSoft, backgroundColor: colors.purpleDeep },
  chipActive: { backgroundColor: colors.surfaceLight, borderColor: colors.goldDark },
  chipText: { color: colors.textMuted, fontFamily: typography.sans, fontSize: 8.5, fontWeight: '600', textAlign: 'center' },
  chipTextActive: { color: colors.goldMuted },
  count: { marginVertical: 12, color: colors.textMuted, fontFamily: typography.sans, fontSize: 9, textAlign: 'right' },
  list: { gap: 7 },
});
