import { Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import type { Href } from 'expo-router';
import { router, useLocalSearchParams } from 'expo-router';
import { useCallback, useEffect, useMemo, useRef, type ReactNode } from 'react';
import { Animated, FlatList, Pressable, ScrollView, StyleSheet, Text, View, type StyleProp, type ViewStyle } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';

import { useReciter } from '../../../context/ReciterProvider';
import { animationCurves, animationDurations } from '../../../core/animations';
import { SURAHS } from '../../../data/surahs';
import { ListeningHeader, ReciterAvatar, SurahAudioRow, listeningStyles } from '../../../features/audio/presentation/ListeningComponents';
import { useSurahCatalogViewModel } from '../../../features/audio/presentation/viewmodels/useSurahCatalogViewModel';
import { useI18n } from '../../../i18n';
import { colors } from '../../../theme/colors';
import { typography } from '../../../theme/typography';

const AnimatedPressable = Animated.createAnimatedComponent(Pressable);

function TactilePressable({ children, onPress, style }: {
  children: ReactNode;
  onPress?: () => void;
  style?: StyleProp<ViewStyle>;
}) {
  const scale = useRef(new Animated.Value(1)).current;
  const animate = (toValue: number) => {
    scale.stopAnimation();
    Animated.timing(scale, {
      toValue,
      duration: 165,
      easing: animationCurves.premium,
      useNativeDriver: true,
      isInteraction: false,
    }).start();
  };

  return (
    <AnimatedPressable
      onPress={onPress}
      onPressIn={() => animate(0.98)}
      onPressOut={() => animate(1)}
      style={[style, { transform: [{ scale }] }]}
    >
      {children}
    </AnimatedPressable>
  );
}

export default function ReciterDetailScreen() {
  const { t } = useI18n();
  const { reciterId: routeReciterId, returnTo } = useLocalSearchParams<{ reciterId?: string; returnTo?: string }>();
  const { currentReciter, reciters, setCurrentReciter } = useReciter();
  const reciterId = routeReciterId ?? currentReciter?.id;
  const reciter = reciters.find((item) => item.id === reciterId);
  const { items, loading } = useSurahCatalogViewModel(reciterId);
  const popularSurahs = useMemo(() => reciter?.popularSurahIds.flatMap((id) => {
    const surah = SURAHS.find((item) => item.id === id);
    return surah ? [surah] : [];
  }) ?? [], [reciter]);
  const totalHours = reciter ? Math.floor(reciter.totalDurationSeconds / 3600) : 0;
  const totalMinutes = reciter ? Math.round((reciter.totalDurationSeconds % 3600) / 60) : 0;
  const headerEntrance = useRef(new Animated.Value(0)).current;
  const heroEntrance = useRef(new Animated.Value(0)).current;
  const statEntrances = useRef([
    new Animated.Value(0),
    new Animated.Value(0),
    new Animated.Value(0),
  ]).current;
  const listEntrance = useRef(new Animated.Value(0)).current;
  const goBack = useCallback(() => {
    if (router.canGoBack()) router.back();
    else router.replace((returnTo || '/reciters') as Href);
  }, [returnTo]);
  const renderSurah = useCallback(({ item }: { item: (typeof items)[number] }) => (
    <SurahAudioRow
      item={item}
      onPress={() => router.push(`/listen/${item.surah.id}?reciterId=${reciterId}&returnTo=${encodeURIComponent(`/listen/reciter/${reciterId}`)}` as Href)}
    />
  ), [reciterId]);
  const keyExtractor = useCallback((item: (typeof items)[number]) => item.track.id, []);

  useEffect(() => {
    const values = [headerEntrance, heroEntrance, ...statEntrances, listEntrance];
    values.forEach((value) => value.setValue(0));
    const enter = (value: Animated.Value, delay: number) => Animated.timing(value, {
      toValue: 1,
      duration: animationDurations.slow,
      delay,
      easing: animationCurves.premium,
      useNativeDriver: true,
      isInteraction: false,
    });
    const animation = Animated.parallel([
      enter(headerEntrance, 0),
      enter(heroEntrance, 45),
      ...statEntrances.map((value, index) => enter(value, 100 + index * 60)),
      enter(listEntrance, 250),
    ]);
    animation.start();
    return () => animation.stop();
  }, [headerEntrance, heroEntrance, listEntrance, reciterId, statEntrances]);

  return (
    <SafeAreaView edges={['top']} style={listeningStyles.safeArea}>
      <FlatList
        data={items}
        keyExtractor={keyExtractor}
        renderItem={renderSurah}
        ItemSeparatorComponent={SurahSeparator}
        contentContainerStyle={listeningStyles.content}
        showsVerticalScrollIndicator={false}
        initialNumToRender={10}
        maxToRenderPerBatch={8}
        updateCellsBatchingPeriod={32}
        windowSize={7}
        removeClippedSubviews
        ListHeaderComponent={<>
        <Animated.View style={{ opacity: headerEntrance, transform: [{ translateY: headerEntrance.interpolate({ inputRange: [0, 1], outputRange: [12, 0] }) }] }}>
          <ListeningHeader title={reciter?.name ?? t('recitations.reciters')} subtitle={t('recitations.reciterSurahs')} onBack={goBack} />
        </Animated.View>
        {reciter ? <>
          <Animated.View style={[styles.heroMotion, { opacity: heroEntrance, transform: [{ translateY: heroEntrance.interpolate({ inputRange: [0, 1], outputRange: [14, 0] }) }] }]}>
            <LinearGradient colors={[colors.surfaceAlt, colors.purpleMid, colors.surfaceAlt]} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={styles.hero}>
            <View style={styles.portraitFrame}>
              <View pointerEvents="none" style={styles.portraitHalo} />
              <ReciterAvatar reciter={reciter} size={124} />
            </View>
            <View style={styles.heroCopy}>
              <Text style={styles.name}>{reciter.name}</Text>
              <Text style={styles.meta}>{reciter.country} · {t(`recitations.style.${reciter.style}`)}</Text>
              <Text style={styles.biography}>{reciter.biography}</Text>
              <TactilePressable onPress={() => void setCurrentReciter(reciter)} style={[styles.preferredButton, currentReciter?.id === reciter.id && styles.preferredButtonActive]}>
                <Ionicons name={currentReciter?.id === reciter.id ? 'star' : 'star-outline'} size={15} color={colors.goldMuted} />
                <Text style={styles.preferredText}>{currentReciter?.id === reciter.id ? t('recitations.preferredReciter') : t('recitations.makePreferredReciter')}</Text>
              </TactilePressable>
            </View>
            </LinearGradient>
          </Animated.View>
          <View style={styles.stats}>
            <Animated.View style={[styles.statSlot, { opacity: statEntrances[0], transform: [{ translateY: statEntrances[0].interpolate({ inputRange: [0, 1], outputRange: [10, 0] }) }] }]}>
              <TactilePressable style={styles.stat}><Stat label={t('recitations.birthYear')} value={reciter.birthYear ? String(reciter.birthYear) : t('common.notAvailable')} /></TactilePressable>
            </Animated.View>
            <Animated.View style={[styles.statSlot, { opacity: statEntrances[1], transform: [{ translateY: statEntrances[1].interpolate({ inputRange: [0, 1], outputRange: [10, 0] }) }] }]}>
              <TactilePressable style={styles.stat}><Stat label={t('quran.surahs')} value={String(reciter.availableSurahs)} /></TactilePressable>
            </Animated.View>
            <Animated.View style={[styles.statSlot, { opacity: statEntrances[2], transform: [{ translateY: statEntrances[2].interpolate({ inputRange: [0, 1], outputRange: [10, 0] }) }] }]}>
              <TactilePressable style={styles.stat}><Stat label={t('recitations.totalDuration')} value={t('recitations.durationHoursMinutes', { hours: totalHours, minutes: totalMinutes })} /></TactilePressable>
            </Animated.View>
          </View>
        </> : null}
        <Animated.View style={{ opacity: listEntrance, transform: [{ translateY: listEntrance.interpolate({ inputRange: [0, 1], outputRange: [14, 0] }) }] }}>
          {reciter ? <>
            <Text style={styles.sectionTitle}>{t('recitations.mostListenedSurahs')}</Text>
            <ScrollView horizontal contentContainerStyle={styles.popularList} showsHorizontalScrollIndicator={false}>
              {popularSurahs.map((surah) => (
                <TactilePressable key={surah.id} onPress={() => router.push(`/listen/${surah.id}?reciterId=${reciter.id}&returnTo=${encodeURIComponent(`/listen/reciter/${reciter.id}`)}` as Href)} style={styles.popularCard}>
                  <Text style={styles.popularNumber}>{surah.id}</Text>
                  <Text numberOfLines={1} style={styles.popularName}>{surah.transliteration}</Text>
                </TactilePressable>
              ))}
            </ScrollView>
            <Text style={styles.sectionTitle}>{t('recitations.allRecitations')}</Text>
          </> : null}
          {loading ? <Text style={listeningStyles.loading}>{t('common.loading')}</Text> : null}
        </Animated.View>
        </>}
      />
    </SafeAreaView>
  );
}

function SurahSeparator() {
  return <View style={styles.surahSeparator} />;
}

function Stat({ label, value }: { label: string; value: string }) {
  return <><Text numberOfLines={1} adjustsFontSizeToFit style={styles.statValue}>{value}</Text><Text style={styles.statLabel}>{label}</Text></>;
}

const styles = StyleSheet.create({
  heroMotion: { marginBottom: 10, borderRadius: 22, backgroundColor: colors.surfaceAlt, shadowColor: '#000', shadowOffset: { width: 0, height: 5 }, shadowOpacity: 0.14, shadowRadius: 14, elevation: 3 },
  hero: { padding: 18, flexDirection: 'row', alignItems: 'center', borderRadius: 22, borderWidth: 1, borderColor: colors.borderSoft },
  portraitFrame: { width: 124, height: 124, alignItems: 'center', justifyContent: 'center' },
  portraitHalo: { position: 'absolute', width: 136, height: 136, borderRadius: 68, backgroundColor: 'rgba(200,148,58,0.09)', shadowColor: colors.gold, shadowOffset: { width: 0, height: 0 }, shadowOpacity: 0.14, shadowRadius: 15, elevation: 2 },
  heroCopy: { flex: 1, marginLeft: 16 },
  name: { color: colors.text, fontFamily: typography.serifMedium, fontSize: 22 },
  meta: { marginTop: 3, color: colors.textMuted, fontFamily: typography.sans, fontSize: 9.5 },
  biography: { marginTop: 8, color: colors.textSecondary, fontFamily: typography.sans, fontSize: 8.5, lineHeight: 13 },
  preferredButton: { minHeight: 32, marginTop: 10, paddingHorizontal: 9, flexDirection: 'row', alignItems: 'center', alignSelf: 'flex-start', borderRadius: 16, borderWidth: 1, borderColor: colors.borderSoft, backgroundColor: colors.purpleDeep },
  preferredButtonActive: { borderColor: colors.goldDark, backgroundColor: colors.surfaceLight },
  preferredText: { marginLeft: 6, color: colors.goldMuted, fontFamily: typography.sans, fontSize: 8, fontWeight: '600' },
  stats: { flexDirection: 'row', gap: 7 },
  statSlot: { flex: 1 },
  stat: { flex: 1, height: 67, paddingHorizontal: 7, alignItems: 'center', justifyContent: 'center', borderRadius: 16, borderWidth: 1, borderColor: colors.borderSoft, backgroundColor: colors.surface, shadowColor: '#000', shadowOffset: { width: 0, height: 3 }, shadowOpacity: 0.12, shadowRadius: 9, elevation: 2 },
  statValue: { width: '100%', color: colors.goldMuted, fontFamily: typography.serifMedium, fontSize: 17, lineHeight: 20, letterSpacing: 0.1, textAlign: 'center' },
  statLabel: { marginTop: 3, color: colors.textMuted, fontFamily: typography.sans, fontSize: 8, fontWeight: '500', letterSpacing: 0.2, textAlign: 'center' },
  sectionTitle: { marginTop: 18, marginBottom: 9, color: colors.goldMuted, fontFamily: typography.serifMedium, fontSize: 19 },
  popularList: { gap: 8, paddingRight: 16 },
  popularCard: { width: 116, minHeight: 66, padding: 10, borderRadius: 16, borderWidth: 1, borderColor: colors.borderSoft, backgroundColor: colors.surfaceAlt, shadowColor: '#000', shadowOffset: { width: 0, height: 3 }, shadowOpacity: 0.12, shadowRadius: 9, elevation: 2 },
  popularNumber: { color: colors.goldMuted, fontFamily: typography.sans, fontSize: 8, fontWeight: '700' },
  popularName: { marginTop: 6, color: colors.text, fontFamily: typography.serifMedium, fontSize: 14 },
  surahSeparator: { height: 7 },
  pressed: { opacity: 0.66 },
});
