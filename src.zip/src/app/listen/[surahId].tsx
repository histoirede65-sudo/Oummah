import type { Href } from 'expo-router';
import { router, useLocalSearchParams } from 'expo-router';
import { useCallback, useEffect, useMemo, useRef, useState, useSyncExternalStore } from 'react';
import { Animated, ScrollView, StyleSheet, useWindowDimensions, type ImageSourcePropType } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';

import AudioPlayer from '../../components/surah/AudioPlayer';
import { usePlayerSwipeGestures } from '../../components/surah/PlayerGestures';
import PlayerQuickMenu from '../../components/surah/PlayerQuickMenu';
import ReciterHero from '../../components/surah/ReciterHero';
import type { ReciterTransitionData } from '../../components/surah/ReciterTransition';
import SurahHeader from '../../components/surah/SurahHeader';
import TadabburControls from '../../components/surah/TadabburControls';
import TadabburVerseFocus from '../../components/surah/TadabburVerseFocus';
import { useGlobalAudioPlayer } from '../../context/AudioPlayerProvider';
import { useReciter } from '../../context/ReciterProvider';
import { animationCurves, animationDurations, premiumAnimations } from '../../core/animations';
import { getTrackReciter, getTrackSurahId, tadabburController, type TadabburVerseState } from '../../core/audio';
import { SURAHS } from '../../data/surahs';
import { AL_FATIHA_VERSES, type Verse } from '../../data/verses/al-fatiha';
import { audioDependencies } from '../../features/audio/audioDependencies';
import { useI18n } from '../../i18n';
import { colors } from '../../theme/colors';

function transitionData(reciter: { id: string; name: string; country: string; style: string; image?: ImageSourcePropType; availableSurahs?: number }): ReciterTransitionData {
  return { id: reciter.id, name: reciter.name, country: reciter.country, style: reciter.style, image: reciter.image, recitationCount: reciter.availableSurahs ?? 114 };
}

export default function SurahListeningScreen() {
  const { t } = useI18n();
  const { surahId, reciterId, returnTo } = useLocalSearchParams<{ surahId: string; reciterId?: string; returnTo?: string }>();
  const { width, height } = useWindowDimensions();
  const compact = width < 370;
  const scrollOffset = useRef(0);
  const previousTadabburVerse = useRef<TadabburVerseState | null>(null);
  const backdropValues = useRef(premiumAnimations.createValues('fadeIn')).current;
  const backdropInitialized = useRef(false);
  const surahOpacity = useRef(new Animated.Value(1)).current;
  const surahTranslateX = useRef(new Animated.Value(0)).current;
  const [quickMenuVisible, setQuickMenuVisible] = useState(false);
  const id = Number(surahId) || 1;
  const surah = SURAHS.find((item) => item.id === id) ?? SURAHS[0];
  const heroHeight = Math.max(368, Math.min(440, Math.round(height * 0.473)));
  const { track, isPlaying, isFavorite, progress, loadSurah, toggleFavorite, cyclePlaybackRate, cycleRepeatMode, cycleSleepTimer } = useGlobalAudioPlayer();
  const { currentReciter, reciters, setCurrentReciter } = useReciter();
  const tadabburMode = useSyncExternalStore(
    tadabburController.subscribe,
    tadabburController.getSnapshot,
    tadabburController.getSnapshot,
  );
  const tadabburVerses = useMemo<readonly Verse[]>(() => (
    surah.id === 1
      ? AL_FATIHA_VERSES
      : [{ id: 1, arabic: t('quran.basmala'), french: surah.frenchName }]
  ), [surah.frenchName, surah.id, t]);
  const versePosition = Math.min(tadabburVerses.length - 1, Math.floor(Math.min(0.999999, progress) * tadabburVerses.length));
  const activeTadabburVerse = tadabburVerses[Math.max(0, versePosition)];
  const activeVerseProgress = Math.min(100, Math.max(0, (progress * tadabburVerses.length - versePosition) * 100));

  const activeSurahId = track ? getTrackSurahId(track) : undefined;
  const activeReciter = track ? getTrackReciter(track) : undefined;
  const transitionReciters = useMemo(() => {
    const selectedReciter = currentReciter
      ?? reciters.find((reciter) => reciter.id === activeReciter?.id)
      ?? reciters[0];
    if (!selectedReciter) return null;
    const activeIndex = reciters.findIndex((item) => item.id === selectedReciter.id);
    const selected = activeIndex >= 0 ? reciters[activeIndex] : selectedReciter;
    if (reciters.length < 2 || activeIndex < 0) return { current: transitionData(selected) };
    return {
      current: transitionData(selected),
      previous: transitionData(reciters[(activeIndex - 1 + reciters.length) % reciters.length]),
      next: transitionData(reciters[(activeIndex + 1) % reciters.length]),
    };
  }, [activeReciter, currentReciter, reciters]);

  const openSurah = useCallback((targetId: number) => {
    if (targetId < 1 || targetId > 114) return;
    const selectedReciterId = currentReciter?.id ?? activeReciter?.id;
    const target = selectedReciterId
      ? `/listen/${targetId}?reciterId=${selectedReciterId}&returnTo=${encodeURIComponent(returnTo || '/reciters')}`
      : `/listen/${targetId}?returnTo=${encodeURIComponent(returnTo || '/reciters')}`;
    router.replace(target as Href);
  }, [activeReciter?.id, currentReciter?.id, returnTo]);
  const goBack = useCallback(() => {
    if (router.canGoBack()) router.back();
    else router.replace((returnTo || '/reciters') as Href);
  }, [returnTo]);
  const collapsePlayer = useCallback(() => {
    if (router.canGoBack()) router.back();
    else router.replace('/reciters');
  }, []);
  const gestureOptions = useMemo(() => ({
    surface: 'full' as const,
    canCollapse: () => scrollOffset.current <= 1,
    onCollapse: collapsePlayer,
    onPrevious: () => openSurah(surah.id - 1),
    onNext: () => openSurah(surah.id + 1),
  }), [collapsePlayer, openSurah, surah.id]);
  const playerGesture = usePlayerSwipeGestures(gestureOptions);
  const currentReciterId = transitionReciters?.current.id;
  const chooseReciter = useCallback((selectedReciterId: string) => {
    const selectedReciter = reciters.find((reciter) => reciter.id === selectedReciterId);
    if (!selectedReciter) return;
    void setCurrentReciter(selectedReciter);
    void loadSurah(surah.id, true, selectedReciterId);
    router.replace(`/listen/${surah.id}?reciterId=${selectedReciterId}&returnTo=${encodeURIComponent(returnTo || '/reciters')}` as Href);
  }, [loadSurah, reciters, returnTo, setCurrentReciter, surah.id]);
  const toggleReciterFavorite = useCallback(() => {
    if (currentReciterId) void audioDependencies.reciterFavorites.toggle(currentReciterId);
  }, [currentReciterId]);
  const toggleTadabbur = useCallback(() => {
    setQuickMenuVisible(false);
    tadabburController.toggle();
  }, []);

  useEffect(() => {
    if (!backdropInitialized.current && !tadabburMode.isActive) {
      backdropInitialized.current = true;
      backdropValues.opacity?.setValue(0);
      return;
    }
    backdropInitialized.current = true;
    const animation = premiumAnimations.start(
      tadabburMode.isActive ? 'fadeIn' : 'fadeOut',
      backdropValues,
    );
    return () => animation.stop();
  }, [backdropValues, tadabburMode.isActive]);

  useEffect(() => {
    if (!tadabburMode.isActive) {
      previousTadabburVerse.current = null;
      return;
    }
    const next: TadabburVerseState = {
      surahId: surah.id,
      verseId: activeTadabburVerse.id,
      progress: activeVerseProgress,
    };
    const previous = previousTadabburVerse.current;
    if (previous && (previous.surahId !== next.surahId || previous.verseId !== next.verseId)) {
      void tadabburController.completeVerse(previous);
    }
    previousTadabburVerse.current = next;
    tadabburController.updateVerse(next);
  }, [activeTadabburVerse.id, activeVerseProgress, surah.id, tadabburMode.isActive]);

  useEffect(() => () => tadabburController.deactivate(), []);

  useEffect(() => {
    surahOpacity.stopAnimation();
    surahTranslateX.stopAnimation();
    surahOpacity.setValue(0.76);
    surahTranslateX.setValue(14);
    const animation = Animated.parallel([
      Animated.timing(surahOpacity, { toValue: 1, duration: animationDurations.normal, easing: animationCurves.premium, useNativeDriver: true, isInteraction: false }),
      Animated.timing(surahTranslateX, { toValue: 0, duration: animationDurations.normal, easing: animationCurves.premium, useNativeDriver: true, isInteraction: false }),
    ]);
    animation.start();
    return () => animation.stop();
  }, [surah.id, surahOpacity, surahTranslateX]);

  useEffect(() => {
    if (activeSurahId !== surah.id || (reciterId && activeReciter?.id !== reciterId)) {
      void loadSurah(surah.id, false, reciterId);
    }
  }, [activeReciter?.id, activeSurahId, loadSurah, reciterId, surah.id]);

  return (
    <SafeAreaView edges={['top']} style={styles.safeArea}>
      <Animated.View pointerEvents="none" style={[StyleSheet.absoluteFill, styles.tadabburBackdrop, { opacity: Animated.multiply(backdropValues.opacity ?? 0, 0.18) }]} />
      <Animated.View {...playerGesture.panHandlers} style={[styles.gestureSurface, playerGesture.animatedStyle]}>
        <Animated.View style={[styles.gestureSurface, { opacity: surahOpacity, transform: [{ translateX: surahTranslateX }] }]}>
        <ScrollView
          contentContainerStyle={[styles.content, compact && styles.contentCompact]}
          showsVerticalScrollIndicator={false}
          scrollEventThrottle={16}
          onScroll={(event) => { scrollOffset.current = event.nativeEvent.contentOffset.y; }}
        >
          <SurahHeader surah={surah} onBack={goBack} audioMode />
          {transitionReciters ? <ReciterHero
            previousReciter={transitionReciters.previous}
            nextReciter={transitionReciters.next}
            surahName={track?.title ?? surah.transliteration}
            verses={surah.verses}
            revelation={surah.revelationType}
            listeners="2,4 M"
            height={heroHeight}
            isPlaying={isPlaying}
            isFavorite={isFavorite}
            onFavorite={() => void toggleFavorite()}
            onReciterPress={() => router.push({ pathname: '/listen/reciters', params: { returnTo: `/listen/${surah.id}` } })}
            onReciterDoubleTap={toggleReciterFavorite}
            focusContent={tadabburMode.isActive ? (
              <TadabburVerseFocus
                verses={tadabburVerses}
                activeVerseId={activeTadabburVerse.id}
                progress={activeVerseProgress}
              />
            ) : undefined}
          /> : null}
          <TadabburControls
            isActive={tadabburMode.isActive}
            pauseSeconds={tadabburMode.settings.pauseAfterVerseSeconds}
            onToggle={toggleTadabbur}
            onCyclePause={() => tadabburController.cyclePauseAfterVerse()}
          />
          <AudioPlayer
            minimal={tadabburMode.isActive}
            onPlayLongPress={tadabburMode.isActive ? undefined : () => setQuickMenuVisible(true)}
          />
        </ScrollView>
        </Animated.View>
      </Animated.View>
      <PlayerQuickMenu
        visible={quickMenuVisible}
        reciters={reciters}
        onClose={() => setQuickMenuVisible(false)}
        onSpeed={cyclePlaybackRate}
        onTimer={cycleSleepTimer}
        onRepeat={cycleRepeatMode}
        onReciter={chooseReciter}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: { flex: 1, backgroundColor: colors.background },
  gestureSurface: { flex: 1 },
  content: { paddingHorizontal: 16, paddingBottom: 60 },
  contentCompact: { paddingHorizontal: 12 },
  tadabburBackdrop: { backgroundColor: '#000' },
});
