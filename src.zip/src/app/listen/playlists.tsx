import { Ionicons } from '@expo/vector-icons';
import type { Href } from 'expo-router';
import { router } from 'expo-router';
import { Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';

import type { Playlist } from '../../core/audio';
import { ListeningHeader, listeningStyles } from '../../features/audio/presentation/ListeningComponents';
import { usePlaylistsViewModel } from '../../features/audio/presentation/viewmodels/usePlaylistsViewModel';
import { useI18n, type TranslationKey } from '../../i18n';
import { colors } from '../../theme/colors';
import { typography } from '../../theme/typography';

export default function AudioPlaylistsScreen() {
  const { t } = useI18n();
  const { collections, loading } = usePlaylistsViewModel();
  const cards: { playlist?: Playlist; key: TranslationKey; icon: keyof typeof Ionicons.glyphMap; route: Href }[] = [
    { playlist: collections?.favorites, key: 'recitations.myFavorites', icon: 'heart-outline', route: '/listen/surahs?filter=favorites' },
    { playlist: collections?.myPlaylist, key: 'recitations.myPlaylist', icon: 'musical-notes-outline', route: '/listen/surahs' },
    { playlist: collections?.recent, key: 'recitations.recentlyListened', icon: 'time-outline', route: '/listen/surahs' },
    { playlist: collections?.downloaded, key: 'recitations.downloaded', icon: 'download-outline', route: '/listen/surahs?filter=downloaded' },
  ];
  return (
    <SafeAreaView edges={['top']} style={listeningStyles.safeArea}>
      <ScrollView contentContainerStyle={listeningStyles.content} showsVerticalScrollIndicator={false}>
        <ListeningHeader title={t('recitations.playlists')} subtitle={t('recitations.playlistsSubtitle')} onBack={() => router.back()} />
        {loading ? <Text style={listeningStyles.loading}>{t('common.loading')}</Text> : null}
        <View style={styles.grid}>{cards.map((card) => <Pressable key={card.key} onPress={() => router.push(card.route)} style={({ pressed }) => [styles.card, pressed && styles.pressed]}><View style={styles.icon}><Ionicons name={card.icon} size={25} color={colors.goldMuted} /></View><Text style={styles.title}>{t(card.key)}</Text><Text style={styles.count}>{t('recitations.trackCount', { count: card.playlist?.items.length ?? 0 })}</Text></Pressable>)}</View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  grid: { flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'space-between', gap: 12 },
  card: { width: '47.5%', minHeight: 148, padding: 16, borderRadius: 21, borderWidth: 1, borderColor: colors.borderSoft, backgroundColor: colors.surfaceAlt },
  icon: { width: 48, height: 48, alignItems: 'center', justifyContent: 'center', borderRadius: 24, backgroundColor: colors.purpleDeep },
  title: { marginTop: 14, color: colors.text, fontFamily: typography.serifMedium, fontSize: 17 },
  count: { marginTop: 3, color: colors.textMuted, fontFamily: typography.sans, fontSize: 9 },
  pressed: { opacity: 0.64 },
});
