import { Ionicons } from '@expo/vector-icons';
import type { Href } from 'expo-router';
import { router, useLocalSearchParams } from 'expo-router';
import { useCallback } from 'react';
import {
  FlatList,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import Reanimated, {
  Easing,
  FadeInDown,
} from 'react-native-reanimated';
import { SafeAreaView } from 'react-native-safe-area-context';

import { useReciter } from '../../context/ReciterProvider';
import type { CatalogReciter } from '../../features/audio/domain/audio';
import {
  ListeningHeader,
  listeningStyles,
} from '../../features/audio/presentation/ListeningComponents';
import ReciterGalleryCard from '../../features/audio/presentation/ReciterGalleryCard';
import { useRecitersViewModel } from '../../features/audio/presentation/viewmodels/useRecitersViewModel';
import { useI18n } from '../../i18n';
import { colors } from '../../theme/colors';
import { typography } from '../../theme/typography';

export default function RecitersCatalogScreen() {
  const { t } = useI18n();

  const { returnTo } = useLocalSearchParams<{
    returnTo?: string;
  }>();

  const model = useRecitersViewModel();

  const {
    currentReciter,
    setCurrentReciter,
  } = useReciter();

  const goBack = useCallback(() => {
    if (router.canGoBack()) {
      router.back();
      return;
    }

    router.replace((returnTo || '/reciters') as Href);
  }, [returnTo]);

  const handleOpenReciter = useCallback(
    async (reciter: CatalogReciter) => {
      await setCurrentReciter(reciter);

      router.push({
        pathname: '/listen/reciter/[reciterId]',
        params: {
          reciterId: reciter.id,
          returnTo: '/listen/reciters',
        },
      });
    },
    [setCurrentReciter],
  );

  const handleSelectReciter = useCallback(
    async (reciter: CatalogReciter) => {
      await setCurrentReciter(reciter);
    },
    [setCurrentReciter],
  );

  const renderReciterItem = useCallback(
    ({
      item,
      index,
    }: {
      item: CatalogReciter;
      index: number;
    }) => (
      <Reanimated.View
        entering={FadeInDown
          .duration(360)
          .delay(Math.min(index, 12) * 24)
          .easing(Easing.out(Easing.quad))
          .withInitialValues({
            opacity: 0,
            transform: [{ translateY: 8 }],
          })}
        style={styles.cardSlot}
      >
        <ReciterGalleryCard
          reciter={item}
          selected={currentReciter?.id === item.id}
          onPress={() => {
            void handleOpenReciter(item);
          }}
          onSelect={() => {
            void handleSelectReciter(item);
          }}
        />
      </Reanimated.View>
    ),
    [
      currentReciter?.id,
      handleOpenReciter,
      handleSelectReciter,
    ],
  );

  return (
    <SafeAreaView
      edges={['top']}
      style={listeningStyles.safeArea}
    >
      <View style={[listeningStyles.content, styles.screenContent]}>
        <ListeningHeader
          title={t('recitations.reciters')}
          subtitle={t('recitations.recitersSubtitle')}
          onBack={goBack}
        />

        <View style={styles.search}>
          <Ionicons
            name="search"
            size={17}
            color={colors.textMuted}
          />

          <TextInput
            value={model.search}
            onChangeText={model.setSearch}
            placeholder={t('recitations.searchReciter')}
            placeholderTextColor={colors.textMuted}
            style={styles.input}
            autoCorrect={false}
            autoCapitalize="none"
            clearButtonMode="while-editing"
          />
        </View>

        <View style={styles.countWrap}>
          <Text style={styles.count}>
            {t('recitations.reciterResultCount', {
              count: model.reciters.length,
            })}
          </Text>
        </View>

        {model.loading ? (
          <Text style={listeningStyles.loading}>
            {t('common.loading')}
          </Text>
        ) : null}

        <FlatList
          style={styles.list}
          data={model.reciters}
          keyExtractor={(item) => item.id}
          renderItem={renderReciterItem}
          numColumns={2}
          columnWrapperStyle={styles.column}
          contentContainerStyle={[
            styles.listContent,
            model.reciters.length === 0 && styles.emptyListContent,
          ]}
          showsVerticalScrollIndicator={false}
          keyboardShouldPersistTaps="handled"
          initialNumToRender={8}
          maxToRenderPerBatch={8}
          windowSize={7}
          ListEmptyComponent={
            !model.loading ? (
              <View style={listeningStyles.empty}>
                <Text style={listeningStyles.emptyText}>
                  {t('recitations.noReciterFound')}
                </Text>
              </View>
            ) : null
          }
        />
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  screenContent: {
    flex: 1,
  },

  search: {
    height: 44,
    paddingHorizontal: 13,
    flexDirection: 'row',
    alignItems: 'center',
    borderRadius: 15,
    borderWidth: 1,
    borderColor: colors.borderSoft,
    backgroundColor: colors.surface,
  },

  input: {
    flex: 1,
    height: '100%',
    marginLeft: 8,
    color: colors.text,
    fontFamily: typography.sans,
    fontSize: 13,
  },

  countWrap: {
    marginTop: 10,
    marginBottom: 8,
    alignItems: 'flex-end',
  },

  count: {
    paddingHorizontal: 10,
    paddingVertical: 5,
    borderRadius: 999,
    backgroundColor: colors.surfaceAlt ?? colors.surface,
    color: colors.textMuted,
    fontFamily: typography.sans,
    fontSize: 10,
    fontWeight: '600',
    textAlign: 'right',
  },

  list: {
    flex: 1,
  },

  listContent: {
    paddingBottom: 30,
  },

  emptyListContent: {
    flexGrow: 1,
  },

  column: {
    gap: 8,
  },

  cardSlot: {
    flex: 1,
    minWidth: 0,
    marginBottom: 12,
  },
});