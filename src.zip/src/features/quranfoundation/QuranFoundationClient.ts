import type {
  QuranFoundationRecitation,
  QuranFoundationReciter,
  QuranFoundationSurah,
  QuranFoundationVerse,
} from "./QuranFoundationTypes";

const SUPABASE_URL =
  process.env.EXPO_PUBLIC_SUPABASE_URL!;

const ANON_KEY =
  process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY!;

export class QuranFoundationClient {
  private surahsCache?: Promise<QuranFoundationSurah[]>;
  private recitersCache?: Promise<QuranFoundationReciter[]>;

  private async request<T>(path: string): Promise<T> {
    console.log("========== QURAN FOUNDATION ==========");
    console.log("SUPABASE_URL:", SUPABASE_URL);
    console.log(
      "ANON_KEY:",
      ANON_KEY ? `${ANON_KEY.substring(0, 20)}...` : "UNDEFINED",
    );
    console.log(
      "REQUEST URL:",
      `${SUPABASE_URL}/functions/v1${path}`,
    );
    console.log("======================================");

    const response = await fetch(
      `${SUPABASE_URL}/functions/v1${path}`,
      {
        method: "GET",
        headers: {
          Authorization: `Bearer ${ANON_KEY}`,
          apikey: ANON_KEY,
          "Content-Type": "application/json",
        },
      },
    );

    if (!response.ok) {
      let message = "";

      try {
        message = await response.text();
      } catch {}

      throw new Error(
        `Quran.Foundation (${response.status}) : ${message}`,
      );
    }

    return response.json() as Promise<T>;
  }

  async getSurahs(): Promise<QuranFoundationSurah[]> {
    if (!this.surahsCache) {
      this.surahsCache =
        this.request<QuranFoundationSurah[]>(
          "/quran-foundation",
        );
    }

    return this.surahsCache;
  }

  async getVerses(
    chapter: number,
  ): Promise<QuranFoundationVerse[]> {
    return this.request<QuranFoundationVerse[]>(
      `/quran-content?chapter=${chapter}`,
    );
  }

  async getReciters(): Promise<QuranFoundationReciter[]> {
    if (!this.recitersCache) {
      this.recitersCache =
        this.request<QuranFoundationReciter[]>(
          "/quran-audio",
        );
    }

    return this.recitersCache;
  }

  async getRecitation(
    reciter: number,
    chapter: number,
  ): Promise<QuranFoundationRecitation> {
    return this.request<QuranFoundationRecitation>(
      `/quran-audio?chapter=${chapter}&reciter=${reciter}`,
    );
  }

  clearCache() {
    this.surahsCache = undefined;
    this.recitersCache = undefined;
  }
}

export const quranFoundationClient =
  new QuranFoundationClient();