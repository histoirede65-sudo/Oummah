export interface QuranFoundationSurah {
  id: number;
  revelationPlace: "makkah" | "madinah";
  revelationOrder: number;
  bismillahPre: boolean;
  nameSimple: string;
  nameComplex: string;
  nameArabic: string;
  versesCount: number;
  pages: number[];
}

export interface QuranFoundationReciter {
  id: number;
  name: string;
  style?: {
    id: number;
    name: string;
  };
}

export interface QuranFoundationVerse {
  id: number;
  verseKey: string;
  textUthmani: string;
  hizbNumber: number;
  juzNumber: number;
  pageNumber: number;
}

export interface QuranFoundationRecitation {
  audioUrl: string;
  timestamps?: {
    verseKey: string;
    timestampFrom: number;
    timestampTo: number;
  }[];
}