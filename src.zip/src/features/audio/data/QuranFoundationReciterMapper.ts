import muhammadSiddiqAlMinshawi from '../../../../assets/reciters/Muhammad Siddiq Al-Minshawi.png';
import abdulBasit from '../../../../assets/reciters/abdul_basit.png';
import abuBakrAlShatri from '../../../../assets/reciters/abu_bakr_alshatri.png';
import ahmedAlAjmi from '../../../../assets/reciters/ahmed_alajmi.png';
import bandarBalila from '../../../../assets/reciters/bandar_balila.png';
import haniArRifai from '../../../../assets/reciters/hani_arrifai.png';
import maherAlMuaiqly from '../../../../assets/reciters/maher_almuaiqly.png';
import mahmoudAlHusary from '../../../../assets/reciters/mahmoud_alhusary.png';
import misharyAlAfasy from '../../../../assets/reciters/mishary_alafasy.png';
import saadAlGhamdi from '../../../../assets/reciters/saad_alghamdi.png';
import shuraim from '../../../../assets/reciters/shuraim.png';
import sudais from '../../../../assets/reciters/sudais.png';
import yasserAlDossari from '../../../../assets/reciters/yasser_aldossari.png';

export const RECITER_IMAGES: Record<number, any> = {
  7: misharyAlAfasy,
  159: maherAlMuaiqly,
  3: sudais,
  10: shuraim,
  13: saadAlGhamdi,
  19: ahmedAlAjmi,
  4: abuBakrAlShatri,
  5: haniArRifai,
  6: mahmoudAlHusary,
  9: muhammadSiddiqAlMinshawi,
  1: abdulBasit,
  2: abdulBasit,
  160: bandarBalila,
  174: yasserAlDossari,
};

export function getReciterImage(id: number) {
  return RECITER_IMAGES[id] ?? misharyAlAfasy;
}