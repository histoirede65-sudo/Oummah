import { quranFoundationRepository } from "../../quranfoundation/QuranFoundationRepository";
import type { CatalogReciter } from "../domain/audio";
import { getReciterImage } from "./QuranFoundationReciterMapper";

export class QuranFoundationReciterDataSource {
  async list(): Promise<CatalogReciter[]> {
    const reciters =
      await quranFoundationRepository.getReciters() as any[];

    return reciters.map((reciter, index) => ({
      id: String(reciter.id),
      name: reciter.name,

      language: "ar",
      country: "",

      style:
        reciter.style?.name?.toLowerCase() === "mujawwad"
          ? "mujawwad"
          : "murattal",

      image: getReciterImage(reciter.id),

      photoUri: String(reciter.id),
      portraitHdUri: String(reciter.id),

      audioSource: "quranfoundation",

      availableSurahs: 114,

      popularity: 100 - index,

      biography: "",

      popularSurahIds: [1, 2, 18, 36, 55, 67],

      totalDurationSeconds: 0,
    }));
  }

  async get(id: string): Promise<CatalogReciter | null> {
    const reciters = await this.list();

    return reciters.find((r) => r.id === id) ?? null;
  }
}