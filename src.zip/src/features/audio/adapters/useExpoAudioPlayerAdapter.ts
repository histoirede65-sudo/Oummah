import { setAudioModeAsync, useAudioPlayer, useAudioPlayerStatus } from 'expo-audio';
import { useEffect, useMemo } from 'react';

import { ExpoAudioPlayerAdapter } from './ExpoAudioPlayerAdapter';

export function useExpoAudioPlayerAdapter() {
  const nativePlayer = useAudioPlayer(null, { updateInterval: 200, keepAudioSessionActive: true });
  const nativeStatus = useAudioPlayerStatus(nativePlayer);
  const adapter = useMemo(() => new ExpoAudioPlayerAdapter(nativePlayer), [nativePlayer]);

  useEffect(() => {
    void setAudioModeAsync({
      playsInSilentMode: true,
      shouldPlayInBackground: true,
      interruptionMode: 'doNotMix',
    }).catch(() => undefined);
  }, []);

  useEffect(() => adapter.sync(nativeStatus), [adapter, nativeStatus]);
  return adapter;
}
