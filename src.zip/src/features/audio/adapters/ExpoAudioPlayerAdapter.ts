import type { AudioPlayer as ExpoPlayer, AudioStatus as ExpoStatus } from 'expo-audio';

import {
  getTrackReciter,
  getTrackUri,
  type AudioPlayer,
  type AudioPlayerStatus,
  type AudioPlayerStatusListener,
  type AudioTrack,
  type PlaybackRate,
  type RepeatMode,
} from '../../../core/audio';

const INITIAL_STATUS: AudioPlayerStatus = {
  isLoaded: false,
  isPlaying: false,
  isBuffering: false,
  didJustFinish: false,
  position: 0,
  duration: 0,
  playbackRate: 1,
  error: null,
};

export class ExpoAudioPlayerAdapter implements AudioPlayer {
  private status = INITIAL_STATUS;
  private listeners = new Set<AudioPlayerStatusListener>();
  private pendingSeek: number | null = null;

  constructor(private readonly player: ExpoPlayer) {}

  load(track: AudioTrack) {
    this.pendingSeek = null;
    this.status = {
      ...this.status,
      isLoaded: false,
      isPlaying: false,
      isBuffering: true,
      didJustFinish: false,
      position: 0,
      duration: track.durationHint ?? 0,
      error: null,
    };
    this.listeners.forEach((listener) => listener(this.status));
    const reciter = getTrackReciter(track);
    this.player.replace({ uri: getTrackUri(track) });
    try {
      this.player.setActiveForLockScreen(true, {
        title: track.title,
        artist: reciter.name,
        albumTitle: 'OUMMAH',
        artworkUrl: track.artworkUri ?? (reciter.photoUri?.startsWith('http') ? reciter.photoUri : undefined),
      }, { showSeekBackward: true, showSeekForward: true });
    } catch {
      // Unsupported on some web and development runtimes.
    }
  }

  play() { this.player.play(); }
  pause() { this.player.pause(); }

  async stop() {
    this.player.pause();
    await this.player.seekTo(0);
  }

  seekTo(seconds: number) {
    if (!this.status.isLoaded) {
      this.pendingSeek = Math.max(0, seconds);
      return Promise.resolve();
    }
    const maximum = this.player.duration > 0 ? this.player.duration : Number.POSITIVE_INFINITY;
    return this.player.seekTo(Math.max(0, Math.min(seconds, maximum)));
  }

  setPlaybackRate(rate: PlaybackRate) {
    this.player.setPlaybackRate(rate);
  }

  setRepeatMode(mode: RepeatMode) {
    this.player.loop = mode === 'surah';
  }

  getStatus() { return this.status; }

  subscribe(listener: AudioPlayerStatusListener) {
    this.listeners.add(listener);
    listener(this.status);
    return () => this.listeners.delete(listener);
  }

  sync(status: ExpoStatus) {
    this.status = {
      isLoaded: status.isLoaded,
      isPlaying: status.playing,
      isBuffering: status.isBuffering,
      didJustFinish: status.didJustFinish,
      position: status.currentTime,
      duration: status.duration,
      playbackRate: status.playbackRate,
      error: 'error' in status ? String((status as { error?: unknown }).error ?? '') || null : null,
    };
    if (status.isLoaded && this.pendingSeek !== null) {
      const position = this.pendingSeek;
      this.pendingSeek = null;
      void this.seekTo(position).catch(() => undefined);
    }
    this.listeners.forEach((listener) => listener(this.status));
  }

  dispose() {
    try {
      this.player.clearLockScreenControls();
    } catch {
      // Optional platform capability.
    }
    this.listeners.clear();
  }
}
