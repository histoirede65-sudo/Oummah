import { useFocusEffect } from 'expo-router';
import { useCallback, useState } from 'react';

import type { ListeningPlaylistsSnapshot } from '../../domain/audio';
import { audioDependencies } from '../../audioDependencies';
import { useReciter } from '../../../../context/ReciterProvider';

export function usePlaylistsViewModel() {
  const { currentReciter } = useReciter();
  const [collections, setCollections] = useState<ListeningPlaylistsSnapshot | null>(null);
  const [loading, setLoading] = useState(true);

  useFocusEffect(useCallback(() => {
    if (!currentReciter) return undefined;
    let active = true;
    setLoading(true);
    void audioDependencies.playlists.collections(currentReciter.id)
      .then((result) => { if (active) setCollections(result); })
      .finally(() => { if (active) setLoading(false); });
    return () => { active = false; };
  }, [currentReciter]));

  return { collections, loading };
}
