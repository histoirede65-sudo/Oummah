import { useFocusEffect } from 'expo-router';
import { useCallback, useState } from 'react';

import { audioDependencies } from '../../audioDependencies';
import type { ListeningHomeSnapshot } from '../../domain/audio';
import { useReciter } from '../../../../context/ReciterProvider';

export function useListeningHomeViewModel() {
  const { currentReciter } = useReciter();
  const [data, setData] = useState<ListeningHomeSnapshot | null>(null);
  const [loading, setLoading] = useState(true);

  useFocusEffect(useCallback(() => {
    if (!currentReciter) return undefined;
    let active = true;
    setLoading(true);
    void audioDependencies.home.load(currentReciter.id)
      .then((snapshot) => { if (active) setData(snapshot); })
      .finally(() => { if (active) setLoading(false); });
    return () => { active = false; };
  }, [currentReciter]));

  return { data, loading };
}
