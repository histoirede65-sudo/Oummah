import { useMemo, useState } from 'react';

import { useReciter } from '../../../../context/ReciterProvider';

function normalize(value: string) {
  return value.normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLocaleLowerCase();
}

export function useRecitersViewModel() {
  const { reciters, loading } = useReciter();
  const [search, setSearch] = useState('');

  const visibleReciters = useMemo(() => {
    const query = normalize(search.trim());
    if (!query) return reciters;
    return reciters.filter((reciter) => (
      normalize(reciter.name).includes(query)
      || normalize(reciter.country).includes(query)
      || normalize(reciter.style).includes(query)
    ));
  }, [reciters, search]);
  return {
    reciters: visibleReciters,
    loading,
    search,
    setSearch,
  };
}
