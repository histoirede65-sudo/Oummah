import { Ionicons } from '@expo/vector-icons';
import { Image } from 'expo-image';
import { type Href, router, usePathname } from 'expo-router';
import { useCallback, useEffect, useMemo } from 'react';
import { Animated, Pressable, StyleSheet, Text, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { useGlobalAudioPlayer } from '../../../context/AudioPlayerProvider';
import { useReciter } from '../../../context/ReciterProvider';
import { getTrackSurahId } from '../../../core/audio';
import { useI18n } from '../../../i18n';
import { colors } from '../../../theme/colors';
import { typography } from '../../../theme/typography';
import { usePlayerSwipeGestures } from '../../../components/surah/PlayerGestures';

export default function MiniPlayer() {
  const { t } = useI18n();
  const pathname = usePathname();
  const insets = useSafeAreaInsets();
  const { currentReciter } = useReciter();
  const {
    track,
    isPlaying,
    progress,
    pause,
    miniPlayerState,
    hideMiniPlayer,
    showMiniPlayer,
    setFullPlayerActive,
  } = useGlobalAudioPlayer();
  const isFullPlayer = /^\/listen\/\d+$/.test(pathname);
  const openFullPlayer = useCallback(() => {
    if (!track || !currentReciter) return;
    const surahId = getTrackSurahId(track);
    if (surahId) router.push(`/listen/${surahId}?returnTo=${encodeURIComponent(pathname)}` as Href);
  }, [currentReciter, pathname, track]);
  const gestureOptions = useMemo(() => ({
    surface: 'mini' as const,
    active: miniPlayerState.mode === 'mini',
    onExpand: openFullPlayer,
    onDismiss: hideMiniPlayer,
  }), [hideMiniPlayer, miniPlayerState.mode, openFullPlayer]);
  const swipeGesture = usePlayerSwipeGestures(gestureOptions);

  useEffect(() => {
    setFullPlayerActive(isFullPlayer);
  }, [isFullPlayer, setFullPlayerActive]);

  if (!track || !currentReciter || isFullPlayer || miniPlayerState.mode === 'full') return null;

  if (miniPlayerState.canRestore) {
    return (
      <Pressable
        accessibilityLabel={t('audio.showMiniPlayer')}
        onPress={showMiniPlayer}
        style={({ pressed }) => [styles.restoreButton, { top: insets.top + 9 }, pressed && styles.pressed]}
      >
        <Ionicons name={isPlaying ? 'volume-high-outline' : 'headset-outline'} size={17} color={colors.goldMuted} />
      </Pressable>
    );
  }

  if (miniPlayerState.mode !== 'mini') return null;
  return (
    <Animated.View
      {...swipeGesture.panHandlers}
      style={[styles.container, { bottom: 67 + insets.bottom }, swipeGesture.animatedStyle]}
    >
      <Pressable
        accessibilityRole="button"
        accessibilityLabel={t('common.openPlayer', { title: track.title })}
        onPress={openFullPlayer}
        style={({ pressed }) => [styles.details, pressed && styles.pressed]}
      >
        <View style={styles.artwork}>
          {currentReciter.image
            ? <Image source={currentReciter.image} contentFit="cover" cachePolicy="memory-disk" priority="high" style={styles.artworkImage} />
            : <Ionicons name="mic" size={18} color={colors.goldMuted} />}
        </View>
        <View style={styles.copy}>
          <Text numberOfLines={1} style={styles.title}>{track.title}</Text>
          <Text numberOfLines={1} style={styles.subtitle}>{currentReciter.name}</Text>
        </View>
      </Pressable>
      <Pressable accessibilityLabel={t('audio.hideMiniPlayer')} onPress={swipeGesture.dismiss} hitSlop={8} style={({ pressed }) => [styles.closeButton, pressed && styles.pressed]}>
        <Ionicons name="close" size={15} color={colors.textMuted} />
      </Pressable>
      <Pressable
        accessibilityRole="button"
        accessibilityLabel={t('common.pause')}
        onPress={pause}
        style={({ pressed }) => [styles.playButton, pressed && styles.pressed]}
      >
        <Ionicons name="pause" size={21} color={colors.background} />
      </Pressable>
      <View style={styles.progressTrack}>
        <View style={[styles.progressFill, { width: `${Math.min(100, Math.max(0, progress * 100))}%` }]} />
      </View>
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  container: {
    position: 'absolute',
    left: 12,
    right: 12,
    height: 58,
    flexDirection: 'row',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: colors.borderSoft,
    borderRadius: 18,
    backgroundColor: colors.surfaceAlt,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.28,
    shadowRadius: 8,
    elevation: 9,
    overflow: 'hidden',
  },
  details: { flex: 1, minWidth: 0, height: '100%', flexDirection: 'row', alignItems: 'center', paddingLeft: 10 },
  artwork: { width: 37, height: 37, alignItems: 'center', justifyContent: 'center', borderRadius: 12, backgroundColor: colors.purpleDeep },
  artworkImage: { width: '100%', height: '100%', borderRadius: 12 },
  copy: { flex: 1, minWidth: 0, marginLeft: 10 },
  title: { color: colors.text, fontFamily: typography.serif, fontSize: 15, fontWeight: '600' },
  subtitle: { marginTop: 1, color: colors.textMuted, fontFamily: typography.sans, fontSize: 9.5, fontWeight: '500' },
  closeButton: { width: 27, height: 37, alignItems: 'center', justifyContent: 'center' },
  playButton: { width: 37, height: 37, marginRight: 9, alignItems: 'center', justifyContent: 'center', borderRadius: 19, backgroundColor: colors.goldLight },
  progressTrack: { position: 'absolute', right: 14, bottom: 0, left: 14, height: 2, backgroundColor: colors.borderSoft },
  progressFill: { height: '100%', backgroundColor: colors.goldLight },
  restoreButton: { position: 'absolute', right: 62, zIndex: 30, width: 36, height: 36, alignItems: 'center', justifyContent: 'center', borderRadius: 18, borderWidth: 1, borderColor: colors.borderSoft, backgroundColor: colors.purpleDeep, elevation: 10 },
  pressed: { opacity: 0.68 },
});
