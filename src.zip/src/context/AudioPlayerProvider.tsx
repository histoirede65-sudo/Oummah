import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState, useSyncExternalStore, type ReactNode } from 'react';
import { AppState } from 'react-native';

import {
  AudioPlayerProvider as CoreAudioPlayerProvider,
  getTrackReciter,
  getTrackSurahId,
  listeningSession,
  resumeService,
  tadabburController,
  useAudioPlayer,
  type ListeningSnapshot,
  type ListeningSnapshotInput,
  type ListeningStateInput,
  type AudioPlayerContextValue as CoreAudioPlayerContextValue,
  type Playlist,
} from '../core/audio';
import { audioDependencies } from '../features/audio/audioDependencies';
import { useExpoAudioPlayerAdapter } from '../features/audio/adapters/useExpoAudioPlayerAdapter';
import { MiniPlayerController } from '../features/audio/presentation/MiniPlayerController';
import type { MiniPlayerState } from '../features/audio/presentation/MiniPlayerState';
import { useReciter } from './ReciterProvider';

type GlobalAudioPlayerContextValue = Omit<CoreAudioPlayerContextValue, 'loadTrack' | 'setPlaylist'> & {
  loadSurah(surahId: number, autoplay?: boolean, reciterId?: string): Promise<void>;
  miniPlayerState: MiniPlayerState;
  hideMiniPlayer(): void;
  showMiniPlayer(): void;
  setFullPlayerActive(active: boolean): void;
  listeningResume: ListeningSnapshot | null;
  resumeListening(): Promise<ListeningSnapshot | null>;
  startNewListening(): Promise<void>;
};

const GlobalAudioPlayerContext = createContext<GlobalAudioPlayerContextValue | null>(null);

function toResumeInput(
  snapshot: CoreAudioPlayerContextValue,
  tadabbur = tadabburController.getSnapshot(),
): ListeningSnapshotInput | null {
  if (!snapshot.track) return null;
  const surahId = getTrackSurahId(snapshot.track);
  if (!surahId) return null;
  const reciter = getTrackReciter(snapshot.track);
  const verseFromTrack = snapshot.track.quran?.verseKey
    ? Number(snapshot.track.quran.verseKey.split(':')[1])
    : null;
  return {
    trackId: snapshot.track.id,
    surahId,
    verseId: tadabbur.isActive && tadabbur.verse?.surahId === surahId
      ? tadabbur.verse.verseId
      : verseFromTrack ?? 1,
    positionSeconds: snapshot.currentTime,
    durationSeconds: snapshot.duration,
    reciterId: reciter.id,
    reciterName: reciter.name,
    playbackRate: snapshot.playbackRate,
    mode: tadabbur.isActive ? 'tadabbur' : 'normal',
    wasPlaying: snapshot.isPlaying,
  };
}

function CompatibilityBridge({ children }: { children: ReactNode }) {
  const player = useAudioPlayer();
  const { currentReciter, reciters, setCurrentReciter } = useReciter();
  const { setPlaylist } = player;
  const playlists = useRef(new Map<string, Playlist>());
  const currentTrack = useRef(player.track);
  const currentPosition = useRef(player.currentTime);
  const previousPlayer = useRef(player);
  const latestPlayer = useRef(player);
  const ignoreNextStop = useRef(false);
  const miniPlayerController = useMemo(() => new MiniPlayerController(), []);
  const [miniPlayerState, setMiniPlayerState] = useState(miniPlayerController.getState());
  const [persistedResume, setPersistedResume] = useState<ListeningSnapshot | null>(null);
  const tadabburMode = useSyncExternalStore(
    tadabburController.subscribe,
    tadabburController.getSnapshot,
    tadabburController.getSnapshot,
  );

  currentTrack.current = player.track;
  currentPosition.current = player.currentTime;
  latestPlayer.current = player;

  useEffect(() => miniPlayerController.subscribe(setMiniPlayerState), [miniPlayerController]);
  useEffect(() => {
    miniPlayerController.syncPlayback(player.track !== null, player.isPlaying);
  }, [miniPlayerController, player.isPlaying, player.track]);

  useEffect(() => {
    let active = true;
    void resumeService.restore()
      .then((session) => { if (active) setPersistedResume(session); })
      .catch(() => undefined);
    return () => { active = false; };
  }, []);

  const remember = useCallback((snapshot: CoreAudioPlayerContextValue) => {
    if (!snapshot.track) return;
    const surahId = getTrackSurahId(snapshot.track);
    if (!surahId) return;
    const reciter = getTrackReciter(snapshot.track);
    const tadabbur = tadabburController.getSnapshot();
    const verseFromTrack = snapshot.track.quran?.verseKey
      ? Number(snapshot.track.quran.verseKey.split(':')[1])
      : null;
    const input: ListeningStateInput = {
      trackId: snapshot.track.id,
      surahId,
      verseId: tadabbur.isActive && tadabbur.verse?.surahId === surahId
        ? tadabbur.verse.verseId
        : verseFromTrack ?? 1,
      positionSeconds: snapshot.currentTime,
      reciterId: reciter.id,
      reciterName: reciter.name,
      playbackRate: snapshot.playbackRate,
      mode: tadabbur.isActive ? 'tadabbur' : 'normal',
    };
    const resumeInput = toResumeInput(snapshot);
    void Promise.all([
      listeningSession.remember(input),
      resumeInput ? resumeService.flush(resumeInput) : Promise.resolve(null),
    ])
      .then(([, resume]) => { if (resume) setPersistedResume(resume); })
      .catch(() => undefined);
  }, []);

  useEffect(() => {
    const input = toResumeInput(player, tadabburMode);
    if (!input || (!player.isPlaying && player.currentTime <= 0)) return;
    resumeService.schedule(input);
  }, [player, tadabburMode]);

  useEffect(() => {
    const flushLatest = () => {
      const input = toResumeInput(latestPlayer.current);
      if (input && (latestPlayer.current.isPlaying || latestPlayer.current.currentTime > 0)) {
        void resumeService.flush(input).catch(() => undefined);
      }
    };
    const subscription = AppState.addEventListener('change', (state) => {
      if (state !== 'active') flushLatest();
    });
    return () => {
      subscription.remove();
      flushLatest();
    };
  }, []);

  useEffect(() => {
    const previous = previousPlayer.current;
    previousPlayer.current = player;
    if (previous.isPlaying && !player.isPlaying) {
      if (ignoreNextStop.current) {
        ignoreNextStop.current = false;
        return;
      }
      remember(previous);
    }
  }, [player, remember]);

  const hideMiniPlayer = useCallback(() => miniPlayerController.hide(), [miniPlayerController]);
  const showMiniPlayer = useCallback(() => miniPlayerController.show(), [miniPlayerController]);
  const setFullPlayerActive = useCallback((active: boolean) => miniPlayerController.setFullPlayer(active), [miniPlayerController]);
  const loadSurah = useCallback(async (surahId: number, autoplay = false, reciterId?: string) => {
    if (reciterId && reciterId !== currentReciter?.id) {
      const selectedReciter = reciters.find((reciter) => reciter.id === reciterId);
      if (selectedReciter) await setCurrentReciter(selectedReciter);
    }
    const resolvedReciterId = reciterId ?? currentReciter?.id;
    if (!resolvedReciterId) return;
    const previousTrack = currentTrack.current;
    const preservePosition = previousTrack !== null
      && getTrackSurahId(previousTrack) === surahId
      && getTrackReciter(previousTrack).id !== resolvedReciterId;
    const position = currentPosition.current;
    let playlist = playlists.current.get(resolvedReciterId);
    if (!playlist) {
      const tracks = await audioDependencies.catalog.listTracks(resolvedReciterId);
      playlist = {
        id: `mock:quran:${resolvedReciterId}`,
        title: 'Quran',
        items: tracks.map((track) => ({ id: track.id, track })),
      };
      playlists.current.set(resolvedReciterId, playlist);
    }
    const item = playlist.items.find((candidate) => candidate.track.quran?.surahId === surahId);
    if (item) {
      setPlaylist(playlist, item.id, autoplay);
      if (preservePosition) await player.seekTo(position);
    }
  }, [currentReciter?.id, player, reciters, setCurrentReciter, setPlaylist]);

  useEffect(() => {
    if (!currentReciter || !player.track) return;
    if (getTrackReciter(player.track).id === currentReciter.id) return;
    const surahId = getTrackSurahId(player.track);
    if (surahId) void loadSurah(surahId, player.isPlaying, currentReciter.id);
  }, [currentReciter, loadSurah, player.isPlaying, player.track]);
  const resumeListening = useCallback(async () => {
    const session = (player.track && (player.isPlaying || player.currentTime > 0))
      ? resumeService.snapshot(toResumeInput(player)!)
      : persistedResume;
    if (!session) return null;
    const sameTrack = player.track?.id === session.trackId;
    if (!sameTrack) await loadSurah(session.surahId, false, session.reciterId);
    if (player.playbackRate !== session.playbackRate) player.setPlaybackRate(session.playbackRate);
    if (!sameTrack || Math.abs(player.currentTime - session.positionSeconds) > 1) {
      await player.seekTo(session.positionSeconds);
    }
    if (session.mode === 'tadabbur') tadabburController.activate();
    else tadabburController.deactivate();
    if (!player.isPlaying) player.resume();
    return session;
  }, [loadSurah, persistedResume, player]);
  const startNewListening = useCallback(async () => {
    ignoreNextStop.current = player.isPlaying;
    await Promise.all([listeningSession.startNew(), resumeService.clear()]);
    setPersistedResume(null);
    await player.stop();
  }, [player]);
  const liveResume = useMemo(() => {
    if (!player.track || (!player.isPlaying && player.currentTime <= 0)) return null;
    const input = toResumeInput(player, tadabburMode);
    return input ? resumeService.snapshot(input) : null;
  }, [player, tadabburMode]);
  const listeningResume = liveResume ?? persistedResume;
  const value = useMemo<GlobalAudioPlayerContextValue>(() => {
    const { loadTrack: _loadTrack, setPlaylist: _setPlaylist, ...state } = player;
    return { ...state, loadSurah, miniPlayerState, hideMiniPlayer, showMiniPlayer, setFullPlayerActive, listeningResume, resumeListening, startNewListening };
  }, [hideMiniPlayer, listeningResume, loadSurah, miniPlayerState, player, resumeListening, setFullPlayerActive, showMiniPlayer, startNewListening]);
  return <GlobalAudioPlayerContext.Provider value={value}>{children}</GlobalAudioPlayerContext.Provider>;
}

export function AudioPlayerProvider({ children }: { children: ReactNode }) {
  const player = useExpoAudioPlayerAdapter();
  return (
    <CoreAudioPlayerProvider
      player={player}
      sessionRepository={audioDependencies.repositories.session}
      history={audioDependencies.repositories.history}
      favorites={audioDependencies.repositories.favorites}
      downloads={audioDependencies.repositories.downloads}
    >
      <CompatibilityBridge>{children}</CompatibilityBridge>
    </CoreAudioPlayerProvider>
  );
}

export function useGlobalAudioPlayer() {
  const context = useContext(GlobalAudioPlayerContext);
  if (!context) throw new Error('useGlobalAudioPlayer must be used within AudioPlayerProvider.');
  return context;
}
