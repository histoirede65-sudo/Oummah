import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from "react";

import { audioDependencies } from "../features/audio/audioDependencies";
import type { CatalogReciter } from "../features/audio/domain/audio";

type ReciterContextValue = {
  currentReciter: CatalogReciter | null;
  reciters: readonly CatalogReciter[];
  loading: boolean;
  setCurrentReciter(reciter: CatalogReciter): Promise<void>;
};

const ReciterContext =
  createContext<ReciterContextValue | null>(null);

export function ReciterProvider({
  children,
}: {
  children: ReactNode;
}) {
  const [reciters, setReciters] = useState<
    readonly CatalogReciter[]
  >([]);

  const [currentReciter, setCurrentReciterState] =
    useState<CatalogReciter | null>(null);

  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let active = true;

    (async () => {
      try {
        const availableReciters =
          await audioDependencies.reciters.list();

        const preferredId =
          await audioDependencies.preferredReciter.getDefaultId();

        if (!active) return;

        setReciters(availableReciters);

        const selected =
          availableReciters.find(
            (reciter) => reciter.id === preferredId,
          ) ??
          availableReciters[0] ??
          null;

        setCurrentReciterState(selected);
      } finally {
        if (active) {
          setLoading(false);
        }
      }
    })();

    return () => {
      active = false;
    };
  }, []);

  const setCurrentReciter = useCallback(
    async (reciter: CatalogReciter) => {
      setCurrentReciterState(reciter);

      await audioDependencies.preferredReciter.setDefault(
        reciter.id,
      );
    },
    [],
  );

  const value = useMemo(
    () => ({
      currentReciter,
      reciters,
      loading,
      setCurrentReciter,
    }),
    [
      currentReciter,
      reciters,
      loading,
      setCurrentReciter,
    ],
  );

  if (loading || !currentReciter) {
    return null;
  }

  return (
    <ReciterContext.Provider value={value}>
      {children}
    </ReciterContext.Provider>
  );
}

export function useReciter() {
  const context = useContext(ReciterContext);

  if (!context) {
    throw new Error(
      "useReciter must be used within ReciterProvider.",
    );
  }

  return context;
}