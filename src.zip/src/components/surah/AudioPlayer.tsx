import { useEffect, useRef } from 'react';
import { Animated, StyleSheet, Text, View } from 'react-native';

import { useGlobalAudioPlayer } from '../../context/AudioPlayerProvider';
import { premiumAnimations } from '../../core/animations';
import { useI18n } from '../../i18n';
import { colors } from '../../theme/colors';
import { typography } from '../../theme/typography';
import AudioProgress from './AudioProgress';
import PlayerControls from './PlayerControls';
import PlayerOptions from './PlayerOptions';

type AudioPlayerProps = { compact?: boolean; minimal?: boolean; onPlayLongPress?: () => void };

function formatTime(seconds: number) {
  if (!Number.isFinite(seconds) || seconds < 0) return '00:00';
  const rounded = Math.floor(seconds);
  const minutes = Math.floor(rounded / 60);
  const remainingSeconds = rounded % 60;
  return `${String(minutes).padStart(2, '0')}:${String(remainingSeconds).padStart(2, '0')}`;
}

export default function AudioPlayer({ compact, minimal, onPlayLongPress }: AudioPlayerProps) {
  const { t } = useI18n();
  const secondaryMotion = useRef(premiumAnimations.createValues('fadeOut')).current;
  const initialized = useRef(false);
  const {
    isPlaying,
    playbackRate,
    repeatMode,
    sleepTimer,
    currentTime,
    duration,
    progress,
    togglePlay,
    skipBy,
    seekTo,
    previous,
    next,
    cycleRepeatMode,
    cyclePlaybackRate,
    cycleSleepTimer,
    prepareDownload,
  } = useGlobalAudioPlayer();

  useEffect(() => {
    if (!initialized.current) {
      initialized.current = true;
      secondaryMotion.opacity?.setValue(minimal ? 0 : 1);
      return;
    }
    const animation = premiumAnimations.start(minimal ? 'fadeOut' : 'fadeIn', secondaryMotion);
    return () => animation.stop();
  }, [minimal, secondaryMotion]);

  return (
    <View style={[styles.wrapper, compact && styles.wrapperCompact]}>
      <AudioProgress progress={progress} elapsed={formatTime(currentTime)} duration={formatTime(duration)} onSeek={(position) => void seekTo(position * duration)} />
      <PlayerControls
        isPlaying={isPlaying}
        onTogglePlay={togglePlay}
        onPlayLongPress={onPlayLongPress}
        onSeekBackward={() => void skipBy(-10)}
        onSeekForward={() => void skipBy(10)}
        onPrevious={() => void previous()}
        onNext={() => void next()}
        compact={compact}
        primaryOnly={minimal}
        secondaryOpacity={secondaryMotion.opacity}
      />
      <Animated.View pointerEvents={minimal ? 'none' : 'auto'} style={{ opacity: secondaryMotion.opacity }}>
        <View style={styles.modeRow}>
          <View style={[styles.modeDot, repeatMode !== 'none' && styles.modeDotActive]} />
          <Text style={styles.modeText}>{t(repeatMode === 'surah' ? 'audio.repeatSurah' : repeatMode === 'verse' ? 'audio.repeatVerse' : 'audio.normal')}</Text>
        </View>
        <PlayerOptions
          repeatMode={repeatMode}
          sleepTimer={sleepTimer}
          playbackRate={playbackRate}
          onCycleRepeat={cycleRepeatMode}
          onCycleSpeed={cyclePlaybackRate}
          onCycleTimer={cycleSleepTimer}
          onPrepareDownload={() => void prepareDownload()}
          compact={compact}
        />
      </Animated.View>
    </View>
  );
}

const styles = StyleSheet.create({
  wrapper: { marginTop: 24 },
  wrapperCompact: { marginTop: 5 },
  modeRow: { marginBottom: 8, flexDirection: 'row', alignItems: 'center', justifyContent: 'center' },
  modeDot: { width: 5, height: 5, marginRight: 6, borderRadius: 3, backgroundColor: colors.textMuted },
  modeDotActive: { backgroundColor: colors.goldMuted },
  modeText: { color: colors.textMuted, fontFamily: typography.sans, fontSize: 8.5, fontWeight: '500' },
});
