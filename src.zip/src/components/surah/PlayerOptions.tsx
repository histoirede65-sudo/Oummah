import { Ionicons } from '@expo/vector-icons';
import { Pressable, StyleSheet, Text, View } from 'react-native';

import { useI18n } from '../../i18n';
import type { RepeatMode, SleepTimerOption } from '../../core/audio';
import { colors } from '../../theme/colors';
import { typography } from '../../theme/typography';

type PlayerOptionsProps = {
  repeatMode: RepeatMode;
  sleepTimer: SleepTimerOption;
  playbackRate: number;
  onCycleRepeat: () => void;
  onCycleSpeed: () => void;
  onCycleTimer: () => void;
  onPrepareDownload: () => void;
  compact?: boolean;
};

export default function PlayerOptions({ repeatMode, sleepTimer, playbackRate, onCycleRepeat, onCycleSpeed, onCycleTimer, onPrepareDownload, compact }: PlayerOptionsProps) {
  const { t } = useI18n();
  const repeatLabel = repeatMode === 'verse'
    ? t('audio.repeatVerse')
    : repeatMode === 'surah'
      ? t('audio.repeatSurah')
      : t('audio.repeat');
  const timerLabel = sleepTimer === 'endOfSurah'
    ? t('audio.timerEnd')
    : typeof sleepTimer === 'number'
      ? t('audio.timerMinutes', { minutes: sleepTimer })
      : t('audio.timer');
  const options = [
    { id: 'speed', label: `${playbackRate}x`, icon: 'speedometer-outline' as const, onPress: onCycleSpeed },
    { id: 'repeat', label: repeatLabel, icon: repeatMode === 'none' ? 'repeat-outline' as const : 'repeat' as const, onPress: onCycleRepeat },
    { id: 'download', label: t('audio.download'), icon: 'download-outline' as const, onPress: onPrepareDownload },
    { id: 'timer', label: timerLabel, icon: 'timer-outline' as const, onPress: onCycleTimer },
  ];

  return (
    <View style={styles.options}>
      {options.map((option) => (
        <Pressable key={option.id} onPress={option.onPress} style={({ pressed }) => [styles.option, compact && styles.optionCompact, repeatMode !== 'none' && option.id === 'repeat' && styles.active, pressed && styles.pressed]}>
          <Ionicons name={option.icon} size={19} color={colors.goldMuted} />
          <Text numberOfLines={1} adjustsFontSizeToFit style={styles.label}>{option.label}</Text>
        </Pressable>
      ))}
    </View>
  );
}

const styles = StyleSheet.create({
  options: { marginTop: 4, flexDirection: 'row', gap: 8 },
  option: { flex: 1, minWidth: 0, height: 76, alignItems: 'center', justifyContent: 'center', borderRadius: 18, borderWidth: 1, borderColor: colors.borderSoft, backgroundColor: colors.surface },
  optionCompact: { height: 43 },
  active: { borderColor: colors.goldDark, backgroundColor: colors.purpleDeep },
  label: { width: '100%', marginTop: 8, color: colors.textSecondary, fontFamily: typography.sans, fontSize: 9, fontWeight: '600', textAlign: 'center' },
  pressed: { opacity: 0.58 },
});
