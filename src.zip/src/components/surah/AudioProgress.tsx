import { useState } from 'react';
import { Pressable, StyleSheet, Text, View, type GestureResponderEvent, type LayoutChangeEvent } from 'react-native';

import { useI18n } from '../../i18n';
import { colors } from '../../theme/colors';
import { typography } from '../../theme/typography';

type AudioProgressProps = { progress?: number; elapsed?: string; duration?: string; onSeek?: (progress: number) => void };

export default function AudioProgress({ progress = 0, elapsed = '00:00', duration = '00:00', onSeek }: AudioProgressProps) {
  const { t } = useI18n();
  const [trackWidth, setTrackWidth] = useState(0);
  const seek = (event: GestureResponderEvent) => {
    if (trackWidth > 0) onSeek?.(Math.max(0, Math.min(1, event.nativeEvent.locationX / trackWidth)));
  };
  const measure = (event: LayoutChangeEvent) => setTrackWidth(event.nativeEvent.layout.width);

  return (
    <View>
      <Pressable accessibilityRole="adjustable" accessibilityLabel={t('audio.seek')} onLayout={measure} onPress={seek} style={styles.track}>
        <View style={[styles.progress, { width: `${Math.max(0, Math.min(1, progress)) * 100}%` }]} />
        <View style={[styles.thumb, { left: `${Math.max(0, Math.min(1, progress)) * 100}%` }]} />
      </Pressable>
      <View style={styles.times}><Text style={styles.time}>{elapsed}</Text><Text style={styles.time}>{duration}</Text></View>
    </View>
  );
}

const styles = StyleSheet.create({
  track: { height: 4, marginHorizontal: 4, borderRadius: 2, backgroundColor: colors.surfaceLight },
  progress: { height: '100%', borderRadius: 2, backgroundColor: colors.goldMuted },
  thumb: { position: 'absolute', top: -3, width: 9, height: 9, marginLeft: -4, borderRadius: 5, backgroundColor: colors.goldMuted, shadowColor: colors.goldMuted, shadowOpacity: 0.8, shadowRadius: 6, elevation: 6 },
  times: { marginTop: 7, marginHorizontal: 12, flexDirection: 'row', justifyContent: 'space-between' },
  time: { color: colors.textMuted, fontFamily: typography.sans, fontSize: 9.5 },
});
