import { Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import { useMemo, type ReactNode } from 'react';
import { Animated, Pressable, StyleSheet, Text, View } from 'react-native';

import { useReciter } from '../../context/ReciterProvider';
import { useI18n } from '../../i18n';
import { colors } from '../../theme/colors';
import { typography } from '../../theme/typography';
import { useDoubleTapGesture } from './PlayerGestures';
import ReciterImage from './ReciterImage';
import ReciterInfo from './ReciterInfo';
import ReciterTransition, { type ReciterTransitionData } from './ReciterTransition';
import WaveVisualizer from './WaveVisualizer';

type ReciterHeroProps = {
  previousReciter?: ReciterTransitionData;
  nextReciter?: ReciterTransitionData;
  surahName: string;
  verses: number;
  revelation: string;
  listeners: string;
  height: number;
  isPlaying: boolean;
  isFavorite?: boolean;
  onFavorite: () => void;
  onReciterPress?: () => void;
  onReciterDoubleTap?: () => void;
  focusContent?: ReactNode;
};

const NOOP = () => undefined;

export default function ReciterHero({
  previousReciter,
  nextReciter,
  surahName,
  verses,
  revelation,
  listeners,
  height,
  isPlaying,
  isFavorite,
  onFavorite,
  onReciterPress,
  onReciterDoubleTap = NOOP,
  focusContent,
}: ReciterHeroProps) {
  const { t } = useI18n();
  const { currentReciter } = useReciter();
  const portraitGesture = useDoubleTapGesture(onReciterDoubleTap);

  const reciter = useMemo<ReciterTransitionData | null>(
    () =>
      currentReciter
        ? {
            id: currentReciter.id,
            name: currentReciter.name,
            country: currentReciter.country,
            style: currentReciter.style,
            image: currentReciter.image,
            recitationCount: currentReciter.availableSurahs,
          }
        : null,
    [currentReciter],
  );

  if (!reciter) return null;

  return (
    <View style={[styles.hero, { height }]}>
      <ReciterTransition
        reciter={reciter}
        previousReciter={previousReciter}
        nextReciter={nextReciter}
      >
        <ReciterImage isPlaying={isPlaying} />

        <LinearGradient
          pointerEvents="none"
          colors={[
            'rgba(8,7,19,0)',
            'rgba(8,7,19,0.16)',
            'rgba(8,7,19,0.7)',
          ]}
          locations={[0, 0.56, 1]}
          start={{ x: 0.08, y: 0.5 }}
          end={{ x: 0.96, y: 0.5 }}
          style={StyleSheet.absoluteFill}
        />

        <LinearGradient
          pointerEvents="none"
          colors={['transparent', colors.background]}
          locations={[0.84, 1]}
          style={StyleSheet.absoluteFill}
        />

        {focusContent ?? (
          <>
            <Pressable
              accessibilityRole="button"
              accessibilityLabel={t('recitations.toggleReciterFavorite')}
              onPress={portraitGesture.onPress}
              style={styles.portraitGesture}
            >
              <Animated.View
                pointerEvents="none"
                style={[styles.favoriteFeedback, portraitGesture.heartStyle]}
              >
                <Ionicons name="heart" size={42} color={colors.goldMuted} />
              </Animated.View>
            </Pressable>

            <View style={styles.identity}>
              <ReciterInfo>
                {(displayed) => (
                  <Pressable
                    accessibilityRole="button"
                    accessibilityLabel={t('recitations.viewReciter', {
                      name: displayed.name,
                    })}
                    onPress={onReciterPress}
                  >
                    <Text
                      numberOfLines={1}
                      adjustsFontSizeToFit
                      style={styles.reciter}
                    >
                      {displayed.name}
                    </Text>
                  </Pressable>
                )}
              </ReciterInfo>

              <View style={styles.surahRow}>
                <Text
                  numberOfLines={1}
                  adjustsFontSizeToFit
                  style={styles.surah}
                >
                  {surahName}
                </Text>

                <Ionicons
                  name="checkmark-circle"
                  size={18}
                  color={stylesConstants.premiumGold}
                />
              </View>

              <View style={styles.metaRow}>
                <View style={styles.revelation}>
                  <Ionicons
                    name="business-outline"
                    size={12}
                    color={stylesConstants.premiumGold}
                  />

                  <Text style={styles.revelationText}>{revelation}</Text>
                </View>

                <Text style={styles.metaText}>
                  {t('common.verseCount', { count: verses })}
                </Text>
              </View>

              <View style={styles.listenersRow}>
                <Ionicons
                  name="people-outline"
                  size={14}
                  color={stylesConstants.premiumGold}
                />

                <Text style={styles.listenersText}>
                  {t('recitations.listeners', { count: listeners })}
                </Text>
              </View>
            </View>

            <Pressable
              accessibilityLabel={t('recitations.addFavorite')}
              onPress={onFavorite}
              style={({ pressed }) => [
                styles.favorite,
                pressed && styles.pressed,
              ]}
            >
              <Ionicons
                name={isFavorite ? 'heart' : 'heart-outline'}
                size={23}
                color={stylesConstants.premiumGold}
              />
            </Pressable>

            <View style={styles.quranCard}>
              <Text
                numberOfLines={1}
                adjustsFontSizeToFit
                style={styles.quranText}
              >
                {t('quran.basmala')}
              </Text>
            </View>

            <View style={styles.wave}>
              <WaveVisualizer
                isPlaying={isPlaying}
                progress={0}
                audioLevel={0.58}
              />
            </View>
          </>
        )}
      </ReciterTransition>
    </View>
  );
}

const stylesConstants = {
  premiumGold: '#D8B65A',
  premiumGoldLight: '#E6D6A8',
} as const;

const styles = StyleSheet.create({
  hero: {
    position: 'relative',
    marginTop: 0,
    marginHorizontal: -16,
    overflow: 'hidden',
    backgroundColor: colors.background,
  },

  identity: {
    position: 'absolute',
    top: '17%',
    right: 8,
    width: '40%',
  },

  reciter: {
    color: stylesConstants.premiumGoldLight,
    fontFamily: typography.serifMedium,
    fontSize: 13,
    fontWeight: '500',
    textAlign: 'right',
  },

  surahRow: {
    marginTop: 4,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'flex-end',
  },

  surah: {
    maxWidth: '88%',
    marginRight: 6,
    color: stylesConstants.premiumGold,
    fontFamily: typography.serifMedium,
    fontSize: 31,
    fontWeight: '500',
    textAlign: 'right',
    textShadowColor: 'rgba(216,182,90,0.35)',
    textShadowOffset: {
      width: 0,
      height: 1,
    },
    textShadowRadius: 8,
  },

  metaRow: {
    marginTop: 8,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'flex-end',
  },

  revelation: {
    paddingHorizontal: 9,
    paddingVertical: 5,
    flexDirection: 'row',
    alignItems: 'center',
    borderRadius: 14,
    borderWidth: 1,
    borderColor: colors.borderSoft,
    backgroundColor: 'rgba(8,7,19,0.58)',
  },

  revelationText: {
    marginLeft: 5,
    color: stylesConstants.premiumGoldLight,
    fontFamily: typography.sans,
    fontSize: 9.5,
    fontWeight: '600',
  },

  metaText: {
    marginLeft: 10,
    color: stylesConstants.premiumGoldLight,
    fontFamily: typography.sans,
    fontSize: 9.5,
  },

  listenersRow: {
    marginTop: 10,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'flex-end',
  },

  listenersText: {
    marginLeft: 7,
    color: stylesConstants.premiumGoldLight,
    fontFamily: typography.sans,
    fontSize: 9,
  },

  favorite: {
    position: 'absolute',
    right: 18,
    bottom: 101,
    width: 48,
    height: 48,
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 24,
    borderWidth: 1,
    borderColor: stylesConstants.premiumGold,
    backgroundColor: 'rgba(8,7,19,0.72)',
  },

  quranCard: {
    position: 'absolute',
    right: 22,
    bottom: 43,
    left: 22,
    minHeight: 56,
    paddingHorizontal: 17,
    paddingVertical: 8,
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 18,
    borderWidth: 0.7,
    borderColor: colors.goldDark,
    backgroundColor: 'rgba(18,10,31,0.94)',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowOpacity: 0.18,
    shadowRadius: 7,
    elevation: 4,
  },

  quranText: {
    width: '100%',
    color: stylesConstants.premiumGold,
    fontFamily: typography.arabic,
    fontSize: 25,
    lineHeight: 36,
    fontWeight: '400',
    textAlign: 'center',
    writingDirection: 'rtl',
    textShadowColor: 'rgba(216,182,90,0.3)',
    textShadowOffset: {
      width: 0,
      height: 0,
    },
    textShadowRadius: 4,
  },

  wave: {
    position: 'absolute',
    right: 24,
    bottom: 4,
    left: 24,
  },

  pressed: {
    opacity: 0.62,
  },

  portraitGesture: {
    position: 'absolute',
    top: 0,
    bottom: 108,
    left: 0,
    width: '48%',
    zIndex: 2,
    alignItems: 'center',
    justifyContent: 'center',
  },

  favoriteFeedback: {
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: colors.gold,
    shadowOpacity: 0.35,
    shadowRadius: 12,
    elevation: 5,
  },
});