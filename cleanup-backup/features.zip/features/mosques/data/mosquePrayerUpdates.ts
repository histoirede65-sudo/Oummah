import { getValidSession } from '../../auth/SupabaseAuthService';
import type { MosquePrayerSchedule } from './mosquePrayerTimes';

export type MosquePrayerTimes = {
  mosqueId: string;
  fajr?: string;
  dhuhr?: string;
  asr?: string;
  maghrib?: string;
  isha?: string;
  jumuah?: string;
  updatedAt?: string;
};

export type MosquePrayerTimeProposal = MosquePrayerTimes & {
  id: string;
  mosqueName: string;
  mosqueAddress?: string;
  note?: string;
  status: 'pending' | 'approved' | 'rejected';
  createdAt: string;
};

const url = process.env.EXPO_PUBLIC_SUPABASE_URL?.replace(/\/+$/, '');
const anon = process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY;
function config() { if (!url || !anon) throw new Error('SUPABASE_NOT_CONFIGURED'); }
function cleanTime(value?: string) {
  const v = value?.trim();
  if (!v) return undefined;
  const digits = v.replace(/\D/g, '');
  let formatted = v;
  if (/^\d{3,4}$/.test(digits)) {
    const padded = digits.padStart(4, '0');
    formatted = `${padded.slice(0,2)}:${padded.slice(2,4)}`;
  }
  if (!/^([01]\d|2[0-3]):[0-5]\d$/.test(formatted)) throw new Error('HORAIRE_INVALIDE');
  return formatted;
}

async function rpc<T>(name: string, body: object, token?: string): Promise<T> {
  config();
  const response = await fetch(`${url}/rest/v1/rpc/${name}`, {
    method: 'POST',
    headers: { apikey: anon!, Authorization: `Bearer ${token ?? anon}`, 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  });
  if (!response.ok) throw new Error(await response.text());
  const responseText = await response.text();
  return (responseText ? JSON.parse(responseText) : undefined) as T;
}

export async function getApprovedMosquePrayerTimes(mosqueId: string): Promise<MosquePrayerTimes | null> {
  const rows = await rpc<Array<{mosque_id:string;fajr:string|null;dhuhr:string|null;asr:string|null;maghrib:string|null;isha:string|null;jumuah:string|null;updated_at:string}>>(
    'get_approved_mosque_prayer_times', { p_mosque_id: mosqueId },
  );
  const row = rows[0];
  return row ? { mosqueId: row.mosque_id, fajr: row.fajr ?? undefined, dhuhr: row.dhuhr ?? undefined, asr: row.asr ?? undefined, maghrib: row.maghrib ?? undefined, isha: row.isha ?? undefined, jumuah: row.jumuah ?? undefined, updatedAt: row.updated_at } : null;
}

export function applyApprovedMosquePrayerTimes(
  schedule: MosquePrayerSchedule,
  approved: MosquePrayerTimes | null,
): MosquePrayerSchedule {
  if (!approved) return schedule;

  const toMinutes = (value: string) => {
    const [hours, minutes] = value.split(':').map(Number);
    return hours * 60 + minutes;
  };
  const formatTime = (timestamp: number, timezone: string) => {
    try {
      return new Intl.DateTimeFormat('fr-FR', { timeZone: timezone, hour: '2-digit', minute: '2-digit', hourCycle: 'h23' }).format(new Date(timestamp));
    } catch {
      return new Date(timestamp).toISOString().slice(11, 16);
    }
  };
  const offsets = new Map<string, number>();
  const todayByKey = new Map(schedule.prayers.map((prayer) => [prayer.key, prayer]));
  for (const prayer of schedule.prayers) {
    const value = approved[prayer.key.toLowerCase() as 'fajr' | 'dhuhr' | 'asr' | 'maghrib' | 'isha'];
    if (value && /^([01]\d|2[0-3]):[0-5]\d$/.test(value)) offsets.set(prayer.key, toMinutes(value) - toMinutes(prayer.time));
  }
  const adjust = (prayer: MosquePrayerSchedule['prayers'][number], future = false) => {
    const offset = offsets.get(prayer.key);
    if (offset === undefined) return prayer;
    const source = todayByKey.get(prayer.key);
    const approvedValue = source && approved[source.key.toLowerCase() as 'fajr' | 'dhuhr' | 'asr' | 'maghrib' | 'isha'];
    const timestamp = future ? prayer.timestamp + offset * 60_000 : source ? source.timestamp + offset * 60_000 : undefined;
    if (!approvedValue || timestamp === undefined) return prayer;
    return { ...prayer, time: future ? formatTime(timestamp, schedule.timezone) : approvedValue, timestamp };
  };

  return {
    ...schedule,
    prayers: schedule.prayers.map((prayer) => adjust(prayer)),
    tomorrowPrayers: schedule.tomorrowPrayers.map((prayer) => adjust(prayer, true)),
    tomorrowFajr: adjust(schedule.tomorrowFajr, true),
  };
}

export async function proposeMosquePrayerTimes(input: MosquePrayerTimes & {mosqueName:string;mosqueAddress?:string;note?:string}) {
  config();
  const session = await getValidSession(true);
  if (!session?.accessToken || !session.user?.id) throw new Error('AUTH_REQUIRED');
  const payload = {
    mosque_id: input.mosqueId, mosque_name: input.mosqueName, mosque_address: input.mosqueAddress?.trim() || null,
    fajr: cleanTime(input.fajr) ?? null, dhuhr: cleanTime(input.dhuhr) ?? null, asr: cleanTime(input.asr) ?? null,
    maghrib: cleanTime(input.maghrib) ?? null, isha: cleanTime(input.isha) ?? null, jumuah: cleanTime(input.jumuah) ?? null,
    note: input.note?.trim() || null, submitted_by: session.user.id, status: 'pending',
  };
  const response = await fetch(`${url}/rest/v1/mosque_prayer_time_updates`, {
    method: 'POST', headers: { apikey: anon!, Authorization: `Bearer ${session.accessToken}`, 'Content-Type':'application/json', Prefer:'return=minimal' }, body: JSON.stringify(payload),
  });
  if (!response.ok) throw new Error(await response.text());
}

export async function adminListMosquePrayerTimeUpdates(): Promise<MosquePrayerTimeProposal[]> {
  const session = await getValidSession(true); if (!session?.accessToken) throw new Error('AUTH_REQUIRED');
  const rows = await rpc<any[]>('admin_list_mosque_prayer_time_updates', {p_status:'pending'}, session.accessToken);
  return rows.map((r) => ({ id:r.id, mosqueId:r.mosque_id, mosqueName:r.mosque_name, mosqueAddress:r.mosque_address ?? undefined,
    fajr:r.fajr ?? undefined,dhuhr:r.dhuhr ?? undefined,asr:r.asr ?? undefined,maghrib:r.maghrib ?? undefined,isha:r.isha ?? undefined,jumuah:r.jumuah ?? undefined,
    note:r.note ?? undefined,status:r.status,createdAt:r.created_at }));
}
export async function adminReviewMosquePrayerTimeUpdate(id:string, approve:boolean) {
  const session = await getValidSession(true); if (!session?.accessToken) throw new Error('AUTH_REQUIRED');
  await rpc('admin_review_mosque_prayer_time_update', {p_id:id,p_approve:approve}, session.accessToken);
}
