export type IslamicQueryExpansion = {
  isIslamicEntity: boolean;
  entityType:
    | "prophet"
    | "companion"
    | "quranic_person"
    | "place"
    | "concept"
    | "event"
    | "unknown";
  canonicalName: string;
  arabicName: string;
  aliases: string[];
  quranSearchTerms: string[];
};

type ExpansionPayload = {
  output_text?: string;
  output?: Array<{
    content?: Array<{ type?: string; text?: string }>;
  }>;
};

function uniqueTerms(values: unknown[]) {
  return [...new Set(
    values
      .map((value) => String(value ?? "").trim())
      .filter((value) => value.length >= 2)
      .slice(0, 12),
  )];
}

function extractJson(payload: ExpansionPayload) {
  const direct = payload.output_text?.trim();
  if (direct) return direct;
  for (const item of payload.output ?? []) {
    for (const content of item.content ?? []) {
      if (content.type === "output_text" && content.text?.trim()) {
        return content.text.trim();
      }
    }
  }
  return "";
}

export async function expandIslamicQuery(
  question: string,
): Promise<IslamicQueryExpansion | null> {
  const apiKey = Deno.env.get("OPENAI_API_KEY");
  if (!apiKey) return null;

  const model = Deno.env.get("WASIL_MODEL_STANDARD") ?? "gpt-5.6-luna";
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 2500);

  try {
    const response = await fetch("https://api.openai.com/v1/responses", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${apiKey}`,
        "Content-Type": "application/json",
      },
      signal: controller.signal,
      body: JSON.stringify({
        model,
        store: false,
        max_output_tokens: 220,
        instructions:
          "Tu normalises une requête islamique pour un moteur de recherche coranique. Ne réponds pas à la question. Identifie l'entité ou le thème religieux visé, même si le nom est biblique, francisé, translittéré ou mal orthographié. Produis uniquement le JSON demandé. Pour quranSearchTerms, fournis les formes les plus utiles pour rechercher dans le Coran en arabe, français et translittération. Ne demande jamais de clarification.",
        input: question,
        text: {
          format: {
            type: "json_schema",
            name: "islamic_query_expansion",
            strict: true,
            schema: {
              type: "object",
              additionalProperties: false,
              properties: {
                isIslamicEntity: { type: "boolean" },
                entityType: {
                  type: "string",
                  enum: [
                    "prophet",
                    "companion",
                    "quranic_person",
                    "place",
                    "concept",
                    "event",
                    "unknown",
                  ],
                },
                canonicalName: { type: "string" },
                arabicName: { type: "string" },
                aliases: {
                  type: "array",
                  items: { type: "string" },
                },
                quranSearchTerms: {
                  type: "array",
                  items: { type: "string" },
                },
              },
              required: [
                "isIslamicEntity",
                "entityType",
                "canonicalName",
                "arabicName",
                "aliases",
                "quranSearchTerms",
              ],
            },
          },
        },
      }),
    });

    if (!response.ok) return null;
    const payload = await response.json() as ExpansionPayload;
    const parsed = JSON.parse(extractJson(payload)) as IslamicQueryExpansion;
    const quranSearchTerms = uniqueTerms([
      parsed.arabicName,
      parsed.canonicalName,
      ...(parsed.aliases ?? []),
      ...(parsed.quranSearchTerms ?? []),
    ]);

    if (!parsed.isIslamicEntity || quranSearchTerms.length === 0) return null;
    return {
      ...parsed,
      aliases: uniqueTerms(parsed.aliases ?? []),
      quranSearchTerms,
    };
  } catch (error) {
    console.warn("WASIL_QUERY_EXPANSION_FAILED", {
      message: error instanceof Error ? error.message : String(error),
    });
    return null;
  } finally {
    clearTimeout(timeout);
  }
}
