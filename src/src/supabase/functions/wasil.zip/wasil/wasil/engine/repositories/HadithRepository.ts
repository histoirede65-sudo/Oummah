export type HadithRepositoryReference = {
  title: string;
  url: string;
};

export type HadithRepositoryItem = {
  id: string | null;
  collection: string;
  reference: string;
  narrator: string | null;
  grade: string | null;
  arabicText: string | null;
  frenchMeaning: string;
  relevance: string;
};

export type HadithRepositoryRecord = {
  repository: "hadith";
  query: string;
  topic: string;
  items: HadithRepositoryItem[];
  cautions: string[];
  references: HadithRepositoryReference[];
  confidence: number;
  fetchedAt: string;
  cacheStatus: "hit" | "miss";
};

type CacheEntry = {
  expiresAt: number;
  value: Omit<HadithRepositoryRecord, "cacheStatus">;
};

type OpenAIResponse = {
  output_text?: string;
  output?: Array<{
    type?: string;
    action?: {
      sources?: Array<{ title?: string; url?: string }>;
    };
    content?: Array<{ type?: string; text?: string }>;
  }>;
};



type HadeethEncSummary = { id?: string | number; title?: string };
type HadeethEncSearchPayload = { data?: HadeethEncSummary[] } | HadeethEncSummary[];
type HadeethEncItem = {
  id?: string | number;
  title?: string;
  hadeeth?: string;
  hadeeth_ar?: string;
  attribution?: string;
  grade?: string;
  explanation?: string;
  reference?: string;
};

const HADEETHENC_API_ROOT = "https://hadeethenc.com/api/v1";

function inferHadithCollection(value: string): string {
  const normalized = normalizeText(value);
  const labels: Array<[RegExp, string]> = [
    [/\b(?:al )?(?:bukhari|boukhari)\b/u, "Sahih al-Bukhari"],
    [/\bmuslim\b/u, "Sahih Muslim"],
    [/\b(?:abu dawud|abou dawoud)\b/u, "Sunan Abu Dawud"],
    [/\b(?:at )?tirmidhi\b/u, "Jami‘ at-Tirmidhi"],
    [/\b(?:an )?nasa i\b/u, "Sunan an-Nasa’i"],
    [/\bibn majah\b/u, "Sunan Ibn Majah"],
    [/\briyad(?: as)? salihin\b/u, "Riyad as-Salihin"],
  ];
  const matches = labels.filter(([pattern]) => pattern.test(normalized)).map(([, label]) => label);
  return matches.length ? matches.join(" et ") : "Hadith authentique";
}

function hadithSearchPhrases(question: string): string[] {
  const normalized = normalizeText(question);
  const aliases: Array<[RegExp, string]> = [
    [/\b(?:patience|patienter|sabr|epreuve|epreuves)\b/u, "patience"],
    [/\b(?:intention|intentions|niyya)\b/u, "intention"],
    [/\b(?:colere|enerve|enervement)\b/u, "colère"],
    [/\b(?:misericorde|rahma)\b/u, "miséricorde"],
    [/\b(?:pardon|pardonner)\b/u, "pardon"],
    [/\b(?:sincerite|ikhlas)\b/u, "sincérité"],
    [/\b(?:priere|salat)\b/u, "prière"],
    [/\b(?:jeune|ramadan)\b/u, "jeûne"],
    [/\b(?:parents|pere|mere)\b/u, "parents"],
    [/\b(?:mariage|epoux|epouse)\b/u, "mariage"],
    [/\b(?:tristesse|angoisse|inquietude)\b/u, "tristesse"],
    [/\b(?:charite|aumone|sadaqa)\b/u, "aumône"],
    [/\b(?:orgueil|arrogance)\b/u, "orgueil"],
    [/\b(?:humilite|modestie)\b/u, "humilité"],
  ];
  const phrases: string[] = [];
  for (const [pattern, phrase] of aliases) {
    if (pattern.test(normalized)) phrases.push(phrase);
  }
  const words = normalized.split(" ").filter((word) => word.length >= 5).slice(0, 5);
  if (words.length) phrases.push(words.join(" "));
  return [...new Set(phrases)];
}

async function fetchHadeethEncJson<T>(path: string, timeoutMs = 5000): Promise<T | null> {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const response = await fetch(`${HADEETHENC_API_ROOT}${path}`, { signal: controller.signal });
    if (!response.ok) return null;
    return await response.json() as T;
  } catch {
    return null;
  } finally {
    clearTimeout(timeout);
  }
}

async function searchHadeethEnc(question: string): Promise<HadithRepositoryRecord | null> {
  for (const phrase of hadithSearchPhrases(question)) {
    const payload = await fetchHadeethEncJson<HadeethEncSearchPayload>(
      `/hadeeths/search/?language=fr&phrase=${encodeURIComponent(phrase)}`,
    );
    if (!payload) continue;
    const summaries = (Array.isArray(payload) ? payload : payload.data ?? [])
      .filter((item) => item.id != null && item.title?.trim());
    if (!summaries.length) continue;

    const details = await Promise.all(summaries.map((summary) =>
      fetchHadeethEncJson<HadeethEncItem>(
        `/hadeeths/one/?language=fr&id=${encodeURIComponent(String(summary.id))}`,
      )
    ));
    const items: HadithRepositoryItem[] = summaries.map((summary, index) => {
      const detail = details[index];
      return {
        id: String(detail?.id ?? summary.id),
        collection: inferHadithCollection(`${detail?.reference ?? ""} ${detail?.attribution ?? ""}`),
        reference: detail?.reference?.trim() || detail?.attribution?.trim() || `Référence n°${String(summary.id)}`,
        narrator: detail?.attribution?.trim() || null,
        grade: detail?.grade?.trim() || null,
        arabicText: detail?.hadeeth_ar?.trim() || null,
        frenchMeaning: detail?.hadeeth?.trim() || summary.title!.trim(),
        relevance: detail?.explanation?.trim().slice(0, 500) || `Hadith pertinent pour le thème « ${phrase} »`,
      };
    }).filter((item) => item.frenchMeaning);
    if (!items.length) continue;

    const value: Omit<HadithRepositoryRecord, "cacheStatus"> = {
      repository: "hadith",
      query: question,
      topic: phrase,
      items,
      cautions: [],
      references: items.map((item) => ({
        title: item.reference,
        url: `https://hadeethenc.com/fr/browse/hadith/${encodeURIComponent(item.id ?? "")}`,
      })),
      confidence: 0.92,
      fetchedAt: new Date().toISOString(),
    };
    return { ...value, cacheStatus: "miss" };
  }
  return null;
}

const CACHE_TTL_MS = 6 * 60 * 60 * 1000;
const hadithCache = new Map<string, CacheEntry>();

function normalizeText(value: string): string {
  return value
    .toLocaleLowerCase("fr")
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[’']/g, " ")
    .replace(/[^a-z0-9\u0600-\u06ff]+/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

function isHadithQuery(question: string): boolean {
  const normalized = normalizeText(question);
  return /\b(hadith|hadiths|sunna|sunnah|tradition|recit rapporte|rapporte par|boukhari|bukhari|muslim|tirmidhi|abou dawoud|abu dawud|nasa i|ibn majah|riyad)\b/.test(
    normalized,
  );
}

function readCache(key: string): HadithRepositoryRecord | null {
  const entry = hadithCache.get(key);
  if (!entry) return null;
  if (entry.expiresAt <= Date.now()) {
    hadithCache.delete(key);
    return null;
  }
  return { ...entry.value, cacheStatus: "hit" };
}

function writeCache(
  key: string,
  value: Omit<HadithRepositoryRecord, "cacheStatus">,
): void {
  hadithCache.set(key, {
    expiresAt: Date.now() + CACHE_TTL_MS,
    value,
  });
}

function normalizeUrl(value: string): string {
  try {
    const url = new URL(value);
    url.hash = "";
    url.pathname = url.pathname.replace(/\/$/, "") || "/";
    return url.toString();
  } catch {
    return "";
  }
}

function outputText(payload: OpenAIResponse): string {
  if (payload.output_text?.trim()) return payload.output_text.trim();
  for (const item of payload.output ?? []) {
    for (const part of item.content ?? []) {
      if (part.type === "output_text" && part.text?.trim()) {
        return part.text.trim();
      }
    }
  }
  return "";
}

function consultedSources(payload: OpenAIResponse): HadithRepositoryReference[] {
  const result = new Map<string, HadithRepositoryReference>();

  for (const item of payload.output ?? []) {
    if (item.type !== "web_search_call") continue;
    for (const raw of item.action?.sources ?? []) {
      if (!raw.url) continue;
      const url = normalizeUrl(raw.url);
      if (!url) continue;
      const host = new URL(url).hostname.replace(/^www\./, "");
      result.set(url, {
        title: raw.title?.trim() || host,
        url,
      });
    }
  }

  return [...result.values()].slice(0, 8);
}

function clampConfidence(value: number): number {
  if (!Number.isFinite(value)) return 0;
  return Math.max(0, Math.min(1, value));
}

/**
 * Experimental, read-only hadith retriever for the V4 shadow pipeline.
 * It is never called unless its feature flag is explicitly enabled.
 * Any retrieval or parsing failure returns null and cannot affect production.
 */
export async function searchHadithRepository(
  question: string,
  options: { force?: boolean } = {},
): Promise<HadithRepositoryRecord | null> {
  if (!options.force && !isHadithQuery(question)) return null;

  const key = normalizeText(question).slice(0, 220);
  const cached = readCache(key);
  if (cached) return cached;

  const directRecord = await searchHadeethEnc(question);
  if (directRecord) {
    const { cacheStatus: _cacheStatus, ...cacheValue } = directRecord;
    writeCache(key, cacheValue);
    return directRecord;
  }

  const apiKey = Deno.env.get("OPENAI_API_KEY");
  if (!apiKey) return null;

  const model = Deno.env.get("WASIL_MODEL_STANDARD") ?? "gpt-5.6-luna";
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 12_000);

  try {
    const response = await fetch("https://api.openai.com/v1/responses", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${apiKey}`,
        "Content-Type": "application/json",
      },
      signal: controller.signal,
      body: JSON.stringify({
        model,
        store: false,
        max_output_tokens: 1200,
        tools: [{ type: "web_search" }],
        tool_choice: "required",
        include: ["web_search_call.action.sources"],
        instructions:
          "Tu es le retriever Hadith de Wasil. Tu ne rédiges jamais la réponse finale. Recherche uniquement des hadiths dont la référence est identifiable. Privilégie les recueils reconnus et les bases qui donnent le recueil, le numéro ou le livre, le narrateur et le degré quand il est disponible. N'invente jamais un numéro, une chaîne, un degré ou un texte arabe. Si les sources divergent, signale-le dans cautions. Le frenchMeaning doit être une reformulation française fidèle et brève, pas une longue citation. Retourne uniquement le JSON demandé.",
        input: `QUESTION UTILISATEUR: ${question}`,
        text: {
          format: {
            type: "json_schema",
            name: "wasil_hadith_repository_record",
            strict: true,
            schema: {
              type: "object",
              additionalProperties: false,
              properties: {
                topic: { type: "string" },
                items: {
                  type: "array",
                  minItems: 1,
                  items: {
                    type: "object",
                    additionalProperties: false,
                    properties: {
                      id: { type: ["string", "null"] },
                      collection: { type: "string" },
                      reference: { type: "string" },
                      narrator: { type: ["string", "null"] },
                      grade: { type: ["string", "null"] },
                      arabicText: { type: ["string", "null"] },
                      frenchMeaning: { type: "string" },
                      relevance: { type: "string" },
                    },
                    required: [
                      "id",
                      "collection",
                      "reference",
                      "narrator",
                      "grade",
                      "arabicText",
                      "frenchMeaning",
                      "relevance",
                    ],
                  },
                },
                cautions: {
                  type: "array",
                  maxItems: 4,
                  items: { type: "string" },
                },
                confidence: { type: "number", minimum: 0, maximum: 1 },
              },
              required: ["topic", "items", "cautions", "confidence"],
            },
          },
        },
      }),
    });

    if (!response.ok) {
      console.warn(
        "WASIL_V4_HADITH_REPOSITORY_HTTP_FAILURE",
        response.status,
        (await response.text()).slice(0, 600),
      );
      return null;
    }

    const payload = await response.json() as OpenAIResponse;
    const references = consultedSources(payload);
    const rawText = outputText(payload);
    if (!rawText) return null;

    const parsed = JSON.parse(rawText) as {
      topic: string;
      items: HadithRepositoryItem[];
      cautions: string[];
      confidence: number;
    };

    const items = Array.isArray(parsed.items)
      ? parsed.items.filter((item) =>
        item?.collection?.trim() &&
        item?.reference?.trim() &&
        item?.frenchMeaning?.trim()
      ).map((item) => ({
        id: item.id?.trim() || null,
        collection: item.collection.trim(),
        reference: item.reference.trim(),
        narrator: item.narrator?.trim() || null,
        grade: item.grade?.trim() || null,
        arabicText: item.arabicText?.trim() || null,
        frenchMeaning: item.frenchMeaning.trim(),
        relevance: item.relevance?.trim() || "",
      }))
      : [];

    if (!parsed.topic?.trim() || items.length === 0 || references.length === 0) {
      console.warn("WASIL_V4_HADITH_REPOSITORY_EMPTY", {
        itemCount: items.length,
        referenceCount: references.length,
      });
      return null;
    }

    const value: Omit<HadithRepositoryRecord, "cacheStatus"> = {
      repository: "hadith",
      query: question,
      topic: parsed.topic.trim(),
      items,
      cautions: (parsed.cautions ?? []).map((item) => item.trim()).filter(Boolean),
      references,
      confidence: clampConfidence(parsed.confidence),
      fetchedAt: new Date().toISOString(),
    };

    writeCache(key, value);
    return { ...value, cacheStatus: "miss" };
  } catch (error) {
    console.warn("WASIL_V4_HADITH_REPOSITORY_FAILURE", {
      message: error instanceof Error ? error.message : String(error),
    });
    return null;
  } finally {
    clearTimeout(timeout);
  }
}
